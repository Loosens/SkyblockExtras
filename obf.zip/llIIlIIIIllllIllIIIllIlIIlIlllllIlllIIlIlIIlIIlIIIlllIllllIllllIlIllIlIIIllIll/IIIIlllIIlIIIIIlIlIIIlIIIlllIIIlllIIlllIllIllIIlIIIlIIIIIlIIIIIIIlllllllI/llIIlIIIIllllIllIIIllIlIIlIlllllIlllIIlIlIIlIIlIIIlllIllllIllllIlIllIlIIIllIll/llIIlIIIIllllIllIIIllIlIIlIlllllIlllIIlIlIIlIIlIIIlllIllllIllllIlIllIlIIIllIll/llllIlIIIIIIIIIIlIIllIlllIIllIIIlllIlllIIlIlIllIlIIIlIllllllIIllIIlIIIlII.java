package llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll;

import java.util.HashMap;

class llllIlIIIIIIIIIIlIIllIlllIIllIIIlllIlllIIlIlIllIlIIIlIllllllIIllIIlIIIlII extends HashMap<String, Integer> {
   final IIllllllIlIIllllIlIlIlllllIIlIlllIlllIIIIIIIlIIlIlllIllllllllllIIIlIIlIIlll llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll;

   llllIlIIIIIIIIIIlIIllIlllIIllIIIlllIlllIIlIlIllIlIIIlIllllllIIllIIlIIIlII(IIllllllIlIIllllIlIlIlllllIIlIlllIlllIIIIIIIlIIlIlllIllllllllllIIIlIIlIIlll var1) {
      this.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll = var1;
      this.put("Smarty Pants", 1);
      this.put("Mana Steal", 2);
      this.put("Twilight Arrow Poison", 3);
      this.put("Null Atom", 4);
      this.put("End Rune", 5);
      this.put("Endersnake Rune", 6);
      this.put("Sinful Dice", 7);
      this.put("Transmission Tuner", 8);
      this.put("Summoning Eye", 9);
      this.put("Etherwarp Merger", 10);
      this.put("Enchant Rune", 11);
      this.put("Handy Blood Chalice", 12);
      this.put("Pocket Espresso Machine", 13);
      this.put("Void Conqueror", 14);
      this.put("Judgement Core", 15);
      this.put("Exceedingly Rare Ender Artifact", 16);
      this.put("Ender Slayer VII", 17);
   }
}
