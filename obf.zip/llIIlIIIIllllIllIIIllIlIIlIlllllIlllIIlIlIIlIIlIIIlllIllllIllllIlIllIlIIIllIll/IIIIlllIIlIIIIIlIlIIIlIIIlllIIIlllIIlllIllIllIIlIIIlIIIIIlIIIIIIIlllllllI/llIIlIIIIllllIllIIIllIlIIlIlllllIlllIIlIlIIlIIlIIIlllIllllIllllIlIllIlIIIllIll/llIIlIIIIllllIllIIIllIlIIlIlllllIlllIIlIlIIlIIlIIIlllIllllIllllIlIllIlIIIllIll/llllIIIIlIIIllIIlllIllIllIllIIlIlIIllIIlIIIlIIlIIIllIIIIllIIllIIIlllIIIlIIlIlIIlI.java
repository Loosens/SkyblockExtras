package llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll;

import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;
import llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IllllIIlIllIlIlIlIIIlIIIIIIIIIIIlIllIIIIIlllIlIlIIlllIIlIlIllIllIlIIlIlIIlI.lllIllIlllIlIllIlIllIllIlIllIllllIIIlIIIIlllIIIIlIlIIlllIIIIlIIIIlllIIIllllIlllIIIl;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.monster.EntityEnderman;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.event.entity.living.EnderTeleportEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class llllIIIIlIIIllIIlllIllIllIllIIlIlIIllIIlIIIlIIlIIIllIIIIllIIllIIIlllIIIlIIlIlIIlI implements llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI {
   public static EntityEnderman lIlllIIIIllIIIlIIlllllIlIlIlllIlIIllllIIllIlIlIllllIlllIlIIIIIlIIIlIIl = null;
   private static EntityEnderman IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI = null;
   private static final Pattern lllIlIIllllIIIIIIIIlIlIIlIIIllIIIllIllllIIllllIlIlIlllIllIllIIlIIIllIIIIllIlI = Pattern.compile("Internalized: (?<value>.+)⸎ Soulflow");
   private static final Pattern lIIIlIlllllIIlIlIIIlIIIIlIlIIIlllIIlIllIlllIIlIllllllllIlIllIIllIIIIIIl = Pattern.compile("\\d+:\\d+");
   private static final Pattern IIllIIllIIIIIlIIIlllIIlIIIIllIlIIllIIIIIllllIIlIIIlIllllIllIllIllIllIlIlllIllIIllll = Pattern.compile(" §3(?<value>\\d+)ʬ");
   private static final Pattern lllIIIlIllIIIIlIlIlIIIIIIllllIIIIlIlIllIlIIllIIIlIIlIlIIlllIlIlIllIlIllIllll = Pattern.compile("§b(?<current>\\d+)/(?<max>\\d+)✎ §3(?<value>\\d+)ʬ");
   private static int lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll = 0;
   private static final Set<BlockPos> lllIIlllIlIIIIIlIllIIllIlllIllIlllIIIIIIlllIIIllIlllIllIlIlIlIIIIlIlllIIlI = new HashSet();
   private static Set<Entity> llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll = new HashSet();
   private static Set<Entity> IllllIIlIllIlIlIlIIIlIIIIIIIIIIIlIllIIIIIlllIlIlIIlllIIlIlIllIllIlIIlIlIIlI = new HashSet();

   public llllIIIIlIIIllIIlllIllIllIllIIlIlIIllIIlIIIlIIlIIIllIIIIllIIllIIIlllIIIlIIlIlIIlI() {
      new lllIlIIllllIIIIIIIIlIlIIlIIIllIIIllIllllIIllllIlIlIlllIllIllIIlIIIllIIIIllIlI();
      new IllllIIlIllIlIlIlIIIlIIIIIIIIIIIlIllIIIIIlllIlIlIIlllIIlIlIllIllIlIIlIlIIlI();
      new lIlllIIIIllIIIlIIlllllIlIlIlllIlIIllllIIllIlIlIllllIlllIlIIIIIlIIIlIIl();
      new lllIIIlIllIIIIlIlIlIIIIIIllllIIIIlIlIllIlIIllIIIlIIlIlIIlllIlIlIllIlIllIllll();
      new lllIIlllIlIIIIIlIllIIllIlllIllIlllIIIIIIlllIIIllIlllIllIlIlIlIIIIlIlllIIlI();
      llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll((llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI)this);
   }

   public static Set<Entity> lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll() {
      return IllllIIlIllIlIlIlIIIlIIIIIIIIIIIlIllIIIIIlllIlIlIIlllIIlIlIllIllIlIIlIlIIlI;
   }

   @SubscribeEvent
   public void llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IllllIIlIllIlIlIlIIIlIIIIIIIIIIIlIllIIIIIlllIlIlIIlllIIlIlIllIllIlIIlIlIIlI.IlIllllIIllllIlllIlllIIIlIllIlIIIlIlllIllIllIIIlIlllIIIIIIlIIIIlIllllIlIIlI param1) {
      // $FF: Couldn't be decompiled
   }

   @SubscribeEvent
   public void llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(EntityJoinWorldEvent param1) {
      // $FF: Couldn't be decompiled
   }

   @SubscribeEvent
   public void llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(lllIllIlllIlIllIlIllIllIlIllIllllIIIlIIIIlllIIIIlIlIIlllIIIIlIIIIlllIIIllllIlllIIIl param1) {
      // $FF: Couldn't be decompiled
   }

   @SubscribeEvent
   public void llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IllllIIlIllIlIlIlIIIlIIIIIIIIIIIlIllIIIIIlllIlIlIIlllIIlIlIllIllIlIIlIlIIlI.lIlllIIIIllIIIlIIlllllIlIlIlllIlIIllllIIllIlIlIllllIlllIlIIIIIlIIIlIIl param1) {
      // $FF: Couldn't be decompiled
   }

   @SubscribeEvent
   public void llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(RenderWorldLastEvent param1) {
      // $FF: Couldn't be decompiled
   }

   @SubscribeEvent
   public void llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(EnderTeleportEvent var1) {
      try {
         if (llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lllIIIlIllIIIIlIlIlIIIIIIllllIIIIlIlIllIlIIllIIIlIIlIlIIlllIlIlIllIlIllIllll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llllIlIIIIIIIIIIlIIllIlllIIllIIIlllIlllIIlIlIllIlIIIlIllllllIIllIIlIIIlII.IllIlIIlIIIlIllIIIIlIllIllIIIlllIlIlIlIlllllIllllIlIlllllIllIIIllIIIIIlIllllIIllll) {
            var1.setCanceled(true);
         }

      } catch (RuntimeException var2) {
         throw IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(var2);
      }
   }

   @SubscribeEvent(
      priority = EventPriority.HIGHEST
   )
   public void llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(ClientChatReceivedEvent param1) {
      // $FF: Couldn't be decompiled
   }

   public void llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll() {
      // $FF: Couldn't be decompiled
   }

   public static boolean IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI() {
      return llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lIlllIIIIllIIIlIIlllllIlIlIlllIlIIllllIIllIlIlIllllIlllIlIIIIIlIIIlIIl.lllIIlllIlIIIIIlIllIIllIlllIllIlllIIIIIIlllIIIllIlllIllIlIlIlIIIIlIlllIIlI();
   }

   public static boolean llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll() {
      return llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lIlllIIIIllIIIlIIlllllIlIlIlllIlIIllllIIllIlIlIllllIlllIlIIIIIlIIIlIIl.IllllIIlIllIlIlIlIIIlIIIIIIIIIIIlIllIIIIIlllIlIlIIlllIIlIlIllIllIlIIlIlIIlI();
   }

   public static boolean lllIIIlIllIIIIlIlIlIIIIIIllllIIIIlIlIllIlIIllIIIlIIlIlIIlllIlIlIllIlIllIllll() {
      boolean var10000;
      try {
         if (!lllIIlllIlIIIIIlIllIIllIlllIllIlllIIIIIIlllIIIllIlllIllIlIlIlIIIIlIlllIIlI.isEmpty()) {
            var10000 = true;
            return var10000;
         }
      } catch (RuntimeException var0) {
         throw IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(var0);
      }

      var10000 = false;
      return var10000;
   }

   private static int llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(String var0) {
      try {
         if (!var0.contains(":")) {
            return 0;
         }
      } catch (Exception var5) {
         throw IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(var5);
      }

      String[] var1 = var0.split(":", 2);

      try {
         int var2 = Integer.parseInt(var1[0]);
         int var3 = Integer.parseInt(var1[1]);
         return var2 * 60 + var3;
      } catch (Exception var4) {
         return 0;
      }
   }

   public static MovingObjectPosition llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(double var0, float var2) {
      Vec3 var3 = Minecraft.func_71410_x().field_71439_g.func_174824_e(var2);
      Vec3 var4 = Minecraft.func_71410_x().field_71439_g.func_70676_i(var2);
      Vec3 var5 = var3.func_72441_c(var4.field_72450_a * var0, var4.field_72448_b * var0, var4.field_72449_c * var0);
      return llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lIlIIIIIIIIllIIlllIllllllIllIllIIllIIllIIlIIlIIIllIIlIIlIIIIlllIlIllIIIlIlll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(var3, var5, true, false, true);
   }

   private static void lambda$onChat$1() {
      IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI = null;
      lIlllIIIIllIIIlIIlllllIlIlIlllIlIIllllIIllIlIlIllllIlllIlIIIIIlIIIlIIl = null;
      llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.clear();
      IllllIIlIllIlIlIlIIIlIIIIIIIIIIIlIllIIIIIlllIlIlIIlllIIlIlIllIllIlIIlIlIIlI.clear();
      llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lIlllIIIIllIIIlIIlllllIlIlIlllIlIIllllIIllIlIlIllllIlllIlIIIIIlIIIlIIl.lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll(false);
      llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lIlllIIIIllIIIlIIlllllIlIlIlllIlIIllllIIllIlIlIllllIlllIlIIIIIlIIIlIIl.IIllllllIlIIllllIlIlIlllllIIlIlllIlllIIIIIIIlIIlIlllIllllllllllIIIlIIlIIlll.lIllllIIllIlIIlIIlIIIlIIIIIIIIllllIIlIIlIIIlIlllllIlIllIIlIIllIlIllIlllIl = false;
      lIlIIIIlllIIllllIlllIIlIIlllIIIIIllIIIIIIllIlIIIIIIIlllIlIlIlllIlIlIIlIIlIlIll.lllIlIIllllIIIIIIIIlIlIIlIIIllIIIllIllllIIllllIlIlIlllIllIllIIlIIIllIIIIllIlI = -1L;
   }

   private static void lambda$onWorldJoinEvent$0(EntityJoinWorldEvent param0) {
      // $FF: Couldn't be decompiled
   }

   static EntityEnderman lllIIlllIlIIIIIlIllIIllIlllIllIlllIIIIIIlllIIIllIlllIllIlIlIlIIIIlIlllIIlI() {
      return IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI;
   }

   static Set IllllIIlIllIlIlIlIIIlIIIIIIIIIIIlIllIIIIIlllIlIlIIlllIIlIlIllIllIlIIlIlIIlI() {
      return lllIIlllIlIIIIIlIllIIllIlllIllIlllIIIIIIlllIIIllIlllIllIlIlIlIIIIlIlllIIlI;
   }

   static int lllIlIIllllIIIIIIIIlIlIIlIIIllIIIllIllllIIllllIlIlIlllIllIllIIlIIIllIIIIllIlI() {
      return lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll;
   }

   private static Exception IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(Exception var0) {
      return var0;
   }
}
