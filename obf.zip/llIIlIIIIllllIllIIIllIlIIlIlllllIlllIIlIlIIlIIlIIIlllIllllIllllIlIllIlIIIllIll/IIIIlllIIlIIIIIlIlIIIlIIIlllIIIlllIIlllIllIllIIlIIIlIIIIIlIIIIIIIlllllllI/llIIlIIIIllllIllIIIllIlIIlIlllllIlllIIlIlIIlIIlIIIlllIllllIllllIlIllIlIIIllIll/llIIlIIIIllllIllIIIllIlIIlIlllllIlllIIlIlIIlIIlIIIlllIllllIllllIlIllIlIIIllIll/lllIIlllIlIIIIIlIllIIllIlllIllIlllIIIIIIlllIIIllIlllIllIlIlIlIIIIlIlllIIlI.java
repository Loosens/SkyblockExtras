package llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll;

class lllIIlllIlIIIIIlIllIIllIlllIllIlllIIIIIIlllIIIllIlllIllIlIlIlIIIIlIlllIIlI extends llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IllllIIlIllIlIlIlIIIlIIIIIIIIIIIlIllIIIIIlllIlIlIIlllIIlIlIllIllIlIIlIlIIlI {
   public lllIIlllIlIIIIIlIllIIllIlllIllIlllIIIIIIlllIIIllIlllIllIlIlIlIIIIlIlllIIlI() {
      super("Overflow Mana Display", 0.6F, 0.9F);
   }

   public int llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll() {
      return 20;
   }

   public int IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI() {
      return 35;
   }

   public boolean lllIlIIllllIIIIIIIIlIlIIlIIIllIIIllIllllIIllllIlIlIlllIllIllIIlIIIllIIIIllIlI() {
      // $FF: Couldn't be decompiled
   }

   public void lIlllIIIIllIIIlIIlllllIlIlIlllIlIIllllIIllIlIlIllllIlllIlIIIIIlIIIlIIl() {
      this.func_73731_b(this.IlIllllIIllllIlllIlllIIIlIllIlIIIlIlllIllIllIIIlIlllIIIIIIlIIIIlIllllIlIIlI.field_71466_p, "§3+ ʬ" + llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llllIIIIlIIIllIIlllIllIllIllIIlIlIIllIIlIIIlIIlIIIllIIIIllIIllIIIlllIIIlIIlIlIIlI.lllIlIIllllIIIIIIIIlIlIIlIIIllIIIllIllllIIllllIlIlIlllIllIllIIlIIIllIIIIllIlI(), 0, 5, 61680);
   }

   public void lllIIlllIlIIIIIlIllIIllIlllIllIlllIIIIIIlllIIIllIlllIllIlIlIlIIIIlIlllIIlI() {
      this.lIlllIIIIllIIIlIIlllllIlIlIlllIlIIllllIIllIlIlIllllIlllIlIIIIIlIIIlIIl();
   }

   private static RuntimeException lllIlIIllllIIIIIIIIlIlIIlIIIllIIIllIllllIIllllIlIlIlllIllIllIIlIIIllIIIIllIlI(RuntimeException var0) {
      return var0;
   }
}
