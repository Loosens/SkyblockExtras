package llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll;

class lIlllIIIIllIIIlIIlllllIlIlIlllIlIIllllIIllIlIlIllllIlllIlIIIIIlIIIlIIl extends llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IllllIIlIllIlIlIlIIIlIIIIIIIIIIIlIllIIIIIlllIlIlIIlllIIlIlIllIllIlIIlIlIIlI {
   private static String IlIIIIIlIIlIllIIllIIlIlllIlIlIIlllIllIIlIIIlIIllIIIIIIIIlIlIIlIIlIlIlllIIIlIl = "";
   private static String IlIllIIIllIlIIIllllllIIllIIlIIllIIlIllIIlIIIlllIlIllIlIlIIIlIIIlIIIIlIIIIlI = "";
   private static long IIllllllIlIIllllIlIlIlllllIIlIlllIlllIIIIIIIlIIlIlllIllllllllllIIIlIIlIIlll = -1L;
   private static boolean IlIIlIlIIIlllIIIIllIIIIIlIIIllllIlllIlllIIIIlIlllIlIlllIIllIIlIllllllIlIllII = false;
   private static boolean llIIIllIIlIllIlIlllllIlllIIlIIlIlIIlIIIIlIlllIlIIIlIIlIlllllIlIllIlIIlIIIIIIlIIllI = false;
   private static boolean IlIlIIlIlIIlllllllIIlIIIIIllllIIllIIlIlIlllIllllIIllIllIlllllIIlIlIlIIlIlI = false;
   private static long lllIllIlllIlIllIlIllIllIlIllIllllIIIlIIIIlllIIIIlIlIIlllIIIIlIIIIlllIIIllllIlllIIIl = -1L;
   private static boolean llllllIllIlllIIlIlIIIlIIIIIIIIlIIlIIllIllllllllIIIIIIllIllIlIIIlIlllIlIIll = false;

   public lIlllIIIIllIIIlIIlllllIlIlIlllIlIIllllIIllIlIlIllllIlllIlIIIIIlIIIlIIl() {
      super("Voidgloom Display", 0.4F, 0.4F);
   }

   public int llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll() {
      return 50;
   }

   public int IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI() {
      return this.IlIllllIIllllIlllIlllIIIlIllIlIIIlIlllIllIllIIIlIlllIIIIIIlIIIIlIllllIlIIlI.field_71466_p.func_78256_a("Voidgloom Seraph 50 Hits  ");
   }

   public boolean lllIlIIllllIIIIIIIIlIlIIlIIIllIIIllIllllIIllllIlIlIlllIllIllIIlIIIllIIIIllIlI() {
      // $FF: Couldn't be decompiled
   }

   public void lIlllIIIIllIIIlIIlllllIlIlIlllIlIIllllIIllIlIlIllllIlllIlIIIIIlIIIlIIl() {
      // $FF: Couldn't be decompiled
   }

   public void lllIIlllIlIIIIIlIllIIllIlllIllIlllIIIIIIlllIIIllIlllIllIlIlIlIIIIlIlllIIlI() {
      this.lllIIIlIllIIIIlIlIlIIIIIIllllIIIIlIlIllIlIIllIIIlIIlIlIIlllIlIlIllIlIllIllll = 0;
      this.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll("Voidgloom Seraph HP", 0, 0, 12879387);
      ++this.lllIIIlIllIIIIlIlIlIIIIIIllllIIIIlIlIllIlIIllIIIlIIlIlIIlllIlIlIllIlIllIllll;
      this.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(16711680, "Hit Phase:", "§cNO");
      this.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(65280, "Holding Beacon:", "§cNO");
      this.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(65280, "Beacon Placed:", "§cNO");
      this.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(261247, "Skulls Nearby:", "§cNO");
   }

   static boolean lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll(boolean var0) {
      IlIIlIlIIIlllIIIIllIIIIIlIIIllllIlllIlllIIIIlIlllIlIlllIIllIIlIllllllIlIllII = var0;
      return var0;
   }

   static long IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(long var0) {
      IIllllllIlIIllllIlIlIlllllIIlIlllIlllIIIIIIIlIIlIlllIllllllllllIIIlIIlIIlll = var0;
      return var0;
   }

   static long lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll() {
      return lllIllIlllIlIllIlIllIllIlIllIllllIIIlIIIIlllIIIIlIlIIlllIIIIlIIIIlllIIIllllIlllIIIl;
   }

   static boolean llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll() {
      return IlIlIIlIlIIlllllllIIlIIIIIllllIIllIIlIlIlllIllllIIllIllIlllllIIlIlIlIIlIlI;
   }

   static boolean lllIlIIllllIIIIIIIIlIlIIlIIIllIIIllIllllIIllllIlIlIlllIllIllIIlIIIllIIIIllIlI(boolean var0) {
      llllllIllIlllIIlIlIIIlIIIIIIIIlIIlIIllIllllllllIIIIIIllIllIlIIIlIlllIlIIll = var0;
      return var0;
   }

   static boolean llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(boolean var0) {
      llIIIllIIlIllIlIlllllIlllIIlIIlIlIIlIIIIlIlllIlIIIlIIlIlllllIlIllIlIIlIIIIIIlIIllI = var0;
      return var0;
   }

   static String IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(String var0) {
      IlIllIIIllIlIIIllllllIIllIIlIIllIIlIllIIlIIIlllIlIllIlIlIIIlIIIlIIIIlIIIIlI = var0;
      return var0;
   }

   static long llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(long var0) {
      lllIllIlllIlIllIlIllIllIlIllIllllIIIlIIIIlllIIIIlIlIIlllIIIIlIIIIlllIIIllllIlllIIIl = var0;
      return var0;
   }

   static String llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(String var0) {
      IlIIIIIlIIlIllIIllIIlIlllIlIlIIlllIllIIlIIIlIIllIIIIIIIIlIlIIlIIlIlIlllIIIlIl = var0;
      return var0;
   }

   static boolean IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(boolean var0) {
      IlIlIIlIlIIlllllllIIlIIIIIllllIIllIIlIlIlllIllllIIllIllIlllllIIlIlIlIIlIlI = var0;
      return var0;
   }

   static boolean IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI() {
      return IlIIlIlIIIlllIIIIllIIIIIlIIIllllIlllIlllIIIIlIlllIlIlllIIllIIlIllllllIlIllII;
   }

   static boolean lllIIlllIlIIIIIlIllIIllIlllIllIlllIIIIIIlllIIIllIlllIllIlIlIlIIIIlIlllIIlI() {
      return llIIIllIIlIllIlIlllllIlllIIlIIlIlIIlIIIIlIlllIlIIIlIIlIlllllIlIllIlIIlIIIIIIlIIllI;
   }

   static boolean IllllIIlIllIlIlIlIIIlIIIIIIIIIIIlIllIIIIIlllIlIlIIlllIIlIlIllIllIlIIlIlIIlI() {
      return llllllIllIlllIIlIlIIIlIIIIIIIIlIIlIIllIllllllllIIIIIIllIllIlIIIlIlllIlIIll;
   }

   private static RuntimeException lllIlIIllllIIIIIIIIlIlIIlIIIllIIIllIllllIIllllIlIlIlllIllIllIIlIIIllIIIIllIlI(RuntimeException var0) {
      return var0;
   }
}
