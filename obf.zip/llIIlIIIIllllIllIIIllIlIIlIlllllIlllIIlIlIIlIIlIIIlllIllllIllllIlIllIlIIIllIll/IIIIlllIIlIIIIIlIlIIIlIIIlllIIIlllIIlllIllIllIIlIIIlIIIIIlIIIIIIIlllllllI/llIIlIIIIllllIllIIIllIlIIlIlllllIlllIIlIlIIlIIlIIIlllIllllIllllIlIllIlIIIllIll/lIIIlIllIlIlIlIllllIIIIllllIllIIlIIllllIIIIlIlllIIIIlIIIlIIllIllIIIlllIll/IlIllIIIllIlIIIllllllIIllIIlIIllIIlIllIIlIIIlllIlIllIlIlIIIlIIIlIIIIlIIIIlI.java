package llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll;

import java.util.Objects;
import net.minecraft.tileentity.TileEntityChest;

class IlIllIIIllIlIIIllllllIIllIIlIIllIIlIllIIlIIIlllIlIllIlIlIIIlIIIlIIIIlIIIIlI {
   private final TileEntityChest llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll;
   private int IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI;

   private IlIllIIIllIlIIIllllllIIllIIlIIllIIlIllIIlIIIlllIlIllIlIlIIIlIIIlIIIIlIIIIlI(TileEntityChest var1) {
      this.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI = 1;
      this.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll = var1;
   }

   public boolean equals(Object var1) {
      try {
         if (this == var1) {
            return true;
         }
      } catch (RuntimeException var3) {
         throw IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(var3);
      }

      try {
         if (!(var1 instanceof IlIllIIIllIlIIIllllllIIllIIlIIllIIlIllIIlIIIlllIlIllIlIlIIIlIIIlIIIIlIIIIlI)) {
            return false;
         }
      } catch (RuntimeException var4) {
         throw IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(var4);
      }

      IlIllIIIllIlIIIllllllIIllIIlIIllIIlIllIIlIIIlllIlIllIlIlIIIlIIIlIIIIlIIIIlI var2 = (IlIllIIIllIlIIIllllllIIllIIlIIllIIlIllIIlIIIlllIlIllIlIlIIIlIIIlIIIIlIIIIlI)var1;
      return Objects.equals(this.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll, var2.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll);
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll});
   }

   static TileEntityChest lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll(IlIllIIIllIlIIIllllllIIllIIlIIllIIlIllIIlIIIlllIlIllIlIlIIIlIIIlIIIIlIIIIlI var0) {
      return var0.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll;
   }

   static int llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(IlIllIIIllIlIIIllllllIIllIIlIIllIIlIllIIlIIIlllIlIllIlIlIIIlIIIlIIIIlIIIIlI var0) {
      return var0.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI++;
   }

   static int llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(IlIllIIIllIlIIIllllllIIllIIlIIllIIlIllIIlIIIlllIlIllIlIlIIIlIIIlIIIIlIIIIlI var0, int var1) {
      return var0.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI = var1;
   }

   static int IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(IlIllIIIllIlIIIllllllIIllIIlIIllIIlIllIIlIIIlllIlIllIlIlIIIlIIIlIIIIlIIIIlI var0) {
      return var0.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI;
   }

   IlIllIIIllIlIIIllllllIIllIIlIIllIIlIllIIlIIIlllIlIllIlIlIIIlIIIlIIIIlIIIIlI(TileEntityChest var1, lllIllIlllIlIllIlIllIllIlIllIllllIIIlIIIIlllIIIIlIlIIlllIIIIlIIIIlllIIIllllIlllIIIl var2) {
      this(var1);
   }

   private static RuntimeException IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(RuntimeException var0) {
      return var0;
   }
}
