package llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll;

import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;

class lIIIlIlllllIIlIlIIIlIIIIlIlIIIlllIIlIllIlllIIlIllllllllIlIllIIllIIIIIIl extends llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IllllIIlIllIlIlIlIIIlIIIIIIIIIIIlIllIIIIIlllIlIlIIlllIIlIlIllIllIlIIlIlIIlI {
   private static final ResourceLocation llIIIllIIlIllIlIlllllIlllIIlIIlIlIIlIIIIlIlllIlIIIlIIlIlllllIlIllIlIIlIIIIIIlIIllI = new ResourceLocation("textures/map/map_icons.png");
   private static final ResourceLocation IIllllllIlIIllllIlIlIlllllIIlIlllIlllIIIIIIIlIIlIlllIllllllllllIIIlIIlIIlll = new ResourceLocation("skyblockextras", "crystalmap.png");

   public lIIIlIlllllIIlIlIIIlIIIIlIlIIIlllIIlIllIlllIIlIllllllllIlIllIIllIIIIIIl() {
      super("Hollows Map", 0.0F, 0.3F, 0.4F);
   }

   public int llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll() {
      return 512;
   }

   public int IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI() {
      return 512;
   }

   public boolean lllIIIlIllIIIIlIlIlIIIIIIllllIIIIlIlIllIlIIllIIIlIIlIlIIlllIlIlIllIlIllIllll() {
      return false;
   }

   public boolean lllIlIIllllIIIIIIIIlIlIIlIIIllIIIllIllllIIllllIlIlIlllIllIllIIlIIIllIIIIllIlI() {
      // $FF: Couldn't be decompiled
   }

   public void lIlllIIIIllIIIlIIlllllIlIlIlllIlIIllllIIllIlIlIllllIlllIlIIIIIlIIIlIIl() {
      Tessellator var1 = Tessellator.func_178181_a();
      WorldRenderer var2 = var1.func_178180_c();
      this.IlIllllIIllllIlllIlllIIIlIllIlIIIlIlllIllIllIIIlIlllIIIIIIlIIIIlIllllIlIIlI.func_110434_K().func_110577_a(IIllllllIlIIllllIlIlIlllllIIlIlllIlllIIIIIIIlIIlIlllIllllllllllIIIlIIlIIlll);
      GlStateManager.func_179124_c(1.0F, 1.0F, 1.0F);
      func_146110_a(0, 0, 0.0F, 0.0F, 512, 512, 512.0F, 512.0F);
      int var3 = (int)(Math.max(0.0D, this.IlIllllIIllllIlllIlllIIIlIllIlIIIlIlllIllIllIIIlIlllIIIIIIlIIIIlIllllIlIIlI.field_71439_g.field_70165_t - 202.0D) * 1024.0D / 1240.0D);
      int var4 = (int)(Math.max(0.0D, this.IlIllllIIllllIlllIlllIIIlIllIlIIIlIlllIllIllIIIlIlllIIIIIIlIIIIlIllllIlIIlI.field_71439_g.field_70161_v - 202.0D) * 1024.0D / 1240.0D);
      GlStateManager.func_179109_b((float)var3, (float)var4, 250.0F);
      this.IlIllllIIllllIlllIlllIIIlIllIlIIIlIlllIllIllIIIlIlllIIIIIIlIIIIlIllllIlIIlI.func_110434_K().func_110577_a(llIIIllIIlIllIlIlllllIlllIIlIIlIlIIlIIIIlIlllIlIIIlIIlIlllllIlIllIlIIlIIIIIIlIIllI);
      GlStateManager.func_179094_E();
      GlStateManager.func_179152_a(16.0F, 16.0F, 3.0F);
      GlStateManager.func_179114_b(MathHelper.func_76142_g(this.IlIllllIIllllIlllIlllIIIlIllIlIIIlIlllIllIllIIIlIlllIIIIIIlIIIIlIllllIlIIlI.field_71439_g.field_70177_z) / 360.0F * 16.0F * 360.0F / 16.0F, 0.0F, 0.0F, 1.0F);
      byte var5 = 1;
      float var6 = (float)(var5 % 4) / 4.0F;
      float var7 = 0.0F;
      float var8 = (float)(var5 % 4 + 1) / 4.0F;
      float var9 = 0.25F;
      GlStateManager.func_179109_b(-0.125F, 0.125F, 0.0F);
      var2.func_181668_a(7, DefaultVertexFormats.field_181707_g);
      var2.func_181662_b(-1.0D, 1.0D, 0.0D).func_181673_a((double)var6, (double)var7).func_181675_d();
      var2.func_181662_b(1.0D, 1.0D, 0.0D).func_181673_a((double)var8, (double)var7).func_181675_d();
      var2.func_181662_b(1.0D, -1.0D, 0.0D).func_181673_a((double)var8, (double)var9).func_181675_d();
      var2.func_181662_b(-1.0D, -1.0D, 0.0D).func_181673_a((double)var6, (double)var9).func_181675_d();
      var1.func_78381_a();
      GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
      GlStateManager.func_179121_F();
      GlStateManager.func_179109_b((float)(-var3), (float)(-var4), -250.0F);
   }

   public void lllIIlllIlIIIIIlIllIIllIlllIllIlllIIIIIIlllIIIllIlllIllIlIlIlIIIIlIlllIIlI() {
      this.lIlllIIIIllIIIlIIlllllIlIlIlllIlIIllllIIllIlIlIllllIlllIlIIIIIlIIIlIIl();
   }

   private static RuntimeException lllIlIIllllIIIIIIIIlIlIIlIIIllIIIllIllllIIllllIlIlIlllIllIllIIlIIIllIIIIllIlI(RuntimeException var0) {
      return var0;
   }
}
