package llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll;

import java.awt.Color;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;

class llIIIllIIlIllIlIlllllIlllIIlIIlIlIIlIIIIlIlllIlIIIlIIlIlllllIlIllIlIIlIIIIIIlIIllI extends llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IllllIIlIllIlIlIlIIIlIIIIIIIIIIIlIllIIIIIlllIlIlIIlllIIlIlIllIllIlIIlIlIIlI {
   private static final ResourceLocation IIllllllIlIIllllIlIlIlllllIIlIlllIlllIIIIIIIlIIlIlllIllllllllllIIIlIIlIIlll = new ResourceLocation("skyblockextras", "dwarvenmap.png");

   public llIIIllIIlIllIlIlllllIlllIIlIIlIlIIlIIIIlIlllIlIIIlIIlIlllllIlIllIlIIlIIIIIIlIIllI() {
      super("Dwarven Map", 0.0F, 0.1F);
   }

   public int llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll() {
      return 753;
   }

   public int IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI() {
      return 481;
   }

   public boolean lllIIIlIllIIIIlIlIlIIIIIIllllIIIIlIlIllIlIIllIIIlIIlIlIIlllIlIlIllIlIllIllll() {
      return false;
   }

   public boolean lllIlIIllllIIIIIIIIlIlIIlIIIllIIIllIllllIIllllIlIlIlllIllIllIIlIIIllIIIIllIlI() {
      // $FF: Couldn't be decompiled
   }

   public void lIlllIIIIllIIIlIIlllllIlIlIlllIlIIllllIIllIlIlIllllIlllIlIIIIIlIIIlIIl() {
      this.IlIllllIIllllIlllIlllIIIlIllIlIIIlIlllIllIllIIIlIlllIIIIIIlIIIIlIllllIlIIlI.func_110434_K().func_110577_a(IIllllllIlIIllllIlIlIlllllIIlIlllIlllIIIIIIIlIIlIlllIllllllllllIIIlIIlIIlll);
      GlStateManager.func_179124_c(1.0F, 1.0F, 1.0F);
      func_146110_a(0, 0, 0.0F, 0.0F, 481, 600, 481.0F, 600.0F);
      int var1 = (int)(Math.max(0.0D, this.IlIllllIIllllIlllIlllIIIlIllIlIIIlIlllIllIllIIIlIlllIIIIIIlIIIIlIllllIlIIlI.field_71439_g.field_70165_t + 200.0D) * 460.0D / 400.0D);
      int var2 = (int)(Math.max(0.0D, this.IlIllllIIllllIlllIlllIIIlIllIlIIIlIlllIllIllIIIlIlllIIIIIIlIIIIlIllllIlIIlI.field_71439_g.field_70161_v + 134.0D) * 480.0D / 334.0D);
      GlStateManager.func_179109_b((float)var1, (float)var2, 250.0F);
      func_73734_a(-4, -4, 4, 4, Color.red.getRGB());
      GlStateManager.func_179109_b((float)(-var1), (float)(-var2), -250.0F);
   }

   public void lllIIlllIlIIIIIlIllIIllIlllIllIlllIIIIIIlllIIIllIlllIllIlIlIlIIIIlIlllIIlI() {
      this.lIlllIIIIllIIIlIIlllllIlIlIlllIlIIllllIIllIlIlIllllIlllIlIIIIIlIIIlIIl();
   }

   private static RuntimeException lllIlIIllllIIIIIIIIlIlIIlIIIllIIIllIllllIIllllIlIlIlllIllIllIIlIIIllIIIIllIlI(RuntimeException var0) {
      return var0;
   }
}
