package llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll;

import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;

class lIlIIIIlllIIllllIlllIIlIIlllIIIIIllIIIIIIllIlIIIIIIIlllIlIlIlllIlIlIIlIIlIlIll extends llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IllllIIlIllIlIlIlIIIlIIIIIIIIIIIlIllIIIIIlllIlIlIIlllIIlIlIllIllIlIIlIlIIlI implements llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI {
   private static final ItemStack IIllllllIlIIllllIlIlIlllllIIlIlllIlllIIIIIIIlIIlIlllIllllllllllIIIlIIlIIlll;
   private static String llIIIllIIlIllIlIlllllIlllIIlIIlIlIIlIIIIlIlllIlIIIlIIlIlllllIlIllIlIIlIIIIIIlIIllI;

   public lIlIIIIlllIIllllIlllIIlIIlllIIIIIllIIIIIIllIlIIIIIIIlllIlIlIlllIlIlIIlIIlIlIll() {
      super("Hollow Pass Timer", 0.4F, 0.4F);
      llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll((llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI)this);
   }

   public int llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll() {
      return 18;
   }

   public int IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI() {
      return 60;
   }

   public boolean lllIlIIllllIIIIIIIIlIlIIlIIIllIIIllIllllIIllllIlIlIlllIllIllIIlIIIllIIIIllIlI() {
      return llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lllIIIlIllIIIIlIlIlIIIIIIllllIIIIlIlIllIlIIllIIIlIIlIlIIlllIlIlIllIlIllIllll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llllIlIIIIIIIIIIlIIllIlllIIllIIIlllIlllIIlIlIllIlIIIlIllllllIIllIIlIIIlII.lIIIlIIllIIIIllIIlIlIllIlIIlIlIIlIIIlIlllIlllIIlIllIIllIIIllIIllIIIllllIllII;
   }

   public void lIlllIIIIllIIIlIIlllllIlIlIlllIlIIllllIIllIlIlIllllIlllIlIIIIIlIIIlIIl() {
      try {
         if (!llIIIllIIlIllIlIlllllIlllIIlIIlIlIIlIIIIlIlllIlIIIlIIlIlllllIlIllIlIIlIIIIIIlIIllI.equals("")) {
            this.lllIIIlIllIIIIlIlIlIIIIIIllllIIIIlIlIllIlIIllIIIlIIlIlIIlllIlIlIllIlIllIllll = 0;
            this.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(IIllllllIlIIllllIlIlIlllllIIlIlllIlllIIIIIIIlIIlIlllIllllllllllIIIlIIlIIlll);
            this.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(llIIIllIIlIllIlIlllllIlllIIlIIlIlIIlIIIIlIlllIlIIIlIIlIlllllIlIllIlIIlIIIIIIlIIllI, 20, this.IlIllllIIllllIlllIlllIIIlIllIlIIIlIlllIllIllIIIlIlllIIIIIIlIIIIlIllllIlIIlI.field_71466_p.field_78288_b / 2, 61680);
         }

      } catch (RuntimeException var1) {
         throw IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(var1);
      }
   }

   public void lllIIlllIlIIIIIlIllIIllIlllIllIlllIIIIIIlllIIIllIlllIllIlIlIlIIIIlIlllIIlI() {
      this.lIlllIIIIllIIIlIIlllllIlIlIlllIlIIllllIIllIlIlIllllIlllIlIIIIIlIIIlIIl();
   }

   public void llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll() throws Exception {
      try {
         llIIIllIIlIllIlIlllllIlllIIlIIlIlIIlIIIIlIlllIlIIIlIIlIlllllIlIllIlIIlIIIIIIlIIllI = llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lllIIIlIllIIIIlIlIlIIIIIIllllIIIIlIlIllIlIIllIIIlIIlIlIIlllIlIlIllIlIllIllll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llllIlIIIIIIIIIIlIIllIlllIIllIIIlllIlllIIlIlIllIlIIIlIllllllIIllIIlIIIlII.IIllIllIIIllIlIlIlIIIllIlllIlIllllllllIlIIIlllIIIlIIllIIIlllIIlIlIllIIIIlIllIII, 18000L);
         if (llIIIllIIlIllIlIlllllIlllIIlIIlIlIIlIIIIlIlllIlIIIlIIlIlllllIlIllIlIIlIIIIIIlIIllI.contains("Ready!")) {
            llIIIllIIlIllIlIlllllIlllIIlIIlIlIIlIIIIlIlllIlIIIlIIlIlllllIlIllIlIIlIIIIIIlIIllI = "§cExpired!";
         }

      } catch (Exception var1) {
         throw IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(var1);
      }
   }

   static {
      IIllllllIlIIllllIlIlIlllllIIlIlllIlllIIIIIIIlIIlIlllIllllllllllIIIlIIlIIlll = new ItemStack(Items.field_151158_bO);
      llIIIllIIlIllIlIlllllIlllIIlIIlIlIIlIIIIlIlllIlIIIlIIlIlllllIlIllIlIIlIIIIIIlIIllI = "";
   }

   private static Exception IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(Exception var0) {
      return var0;
   }
}
