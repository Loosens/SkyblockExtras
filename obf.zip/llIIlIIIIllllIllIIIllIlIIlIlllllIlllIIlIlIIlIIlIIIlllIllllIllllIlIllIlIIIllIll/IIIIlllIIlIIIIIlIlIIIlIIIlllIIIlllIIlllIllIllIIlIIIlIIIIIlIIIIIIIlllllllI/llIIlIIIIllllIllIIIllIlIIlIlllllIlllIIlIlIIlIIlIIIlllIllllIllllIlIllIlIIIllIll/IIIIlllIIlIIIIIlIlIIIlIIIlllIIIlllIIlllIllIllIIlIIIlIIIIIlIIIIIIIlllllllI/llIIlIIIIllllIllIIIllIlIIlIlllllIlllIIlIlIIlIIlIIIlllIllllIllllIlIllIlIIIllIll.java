package llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI;

import java.util.HashMap;

final class llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll extends HashMap<String, Integer> {
   llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll() {
      this.put("A Squid appeared.", 0);
      this.put("Pitch darkness reveals a Night Squid.", 0);
      this.put("You caught a Sea Walker.", 1);
      this.put("You stumbled upon a Sea Guardian.", 2);
      this.put("It looks like you've disrupted the Sea Witch's brewing session. Watch out, she's furious!", 3);
      this.put("You reeled in a Sea Archer.", 4);
      this.put("The Monster of the Deep has emerged.", 5);
      this.put("Huh? A Catfish!", 6);
      this.put("Gross! A Sea Leech!", 7);
      this.put("You've discovered a Guardian Defender of the sea.", 8);
      this.put("You have awoken the Deep Sea Protector, prepare for a battle!", 9);
      this.put("The Water Hydra has come to test your strength.", 10);
      this.put("The Sea Emperor arises from the depths.", 11);
      this.put("A tiny fin emerges from the water, you've caught a Nurse Shark.", 12);
      this.put("You spot a fin as blue as the water it came from, it's a Blue Shark.", 13);
      this.put("A striped beast bounds from the depths, the wild Tiger Shark!", 14);
      this.put("Hide no longer, a Great White Shark has tracked your scent and thirsts for your blood!", 15);
      this.put("Frozen Steve fell into the pond long ago, never to resurface...until now!", 16);
      this.put("It's a snowman! He looks harmless", 17);
      this.put("The Grinch stole Jerry's Gifts...get them back!", 18);
      this.put("What is this creature!?", 19);
      this.put("Phew! It's only a Scarecrow.", 20);
      this.put("You hear trotting from beneath the waves, you caught a Nightmare.", 21);
      this.put("It must be a full moon, a Werewolf appears.", 22);
      this.put("The spirit of a long lost Phantom Fisher has come to haunt you.", 23);
      this.put("This can't be! The manifestation of death himself!", 24);
      this.put("A Water Worm surfaces!", 25);
      this.put("A Poisoned Worm surfaces!", 26);
      this.put("A flaming worm surfaces from the depths!", 27);
      this.put("A Lava Blaze has surfaced from the depths!", 28);
      this.put("A Lava Pigman arose from the depths!", 29);
   }
}
