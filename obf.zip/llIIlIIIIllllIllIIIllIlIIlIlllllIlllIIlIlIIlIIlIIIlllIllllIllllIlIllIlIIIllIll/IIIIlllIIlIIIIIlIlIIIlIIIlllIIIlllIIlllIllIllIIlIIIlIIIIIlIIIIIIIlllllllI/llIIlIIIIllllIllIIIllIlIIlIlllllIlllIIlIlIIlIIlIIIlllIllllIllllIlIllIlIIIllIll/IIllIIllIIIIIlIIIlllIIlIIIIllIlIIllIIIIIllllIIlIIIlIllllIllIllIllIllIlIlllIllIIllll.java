package llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll;

import java.util.regex.Pattern;
import llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IllllIIlIllIlIlIlIIIlIIIIIIIIIIIlIllIIIIIlllIlIlIIlllIIlIlIllIllIlIIlIlIIlI.lllIllIlllIlIllIlIllIllIlIllIllllIIIlIIIIlllIIIIlIlIIlllIIIIlIIIIlllIIIllllIlllIIIl;
import llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IIlllIlIIllllIIIIIIlIIllllIllIlIIlIlllIIlIIlllIlIIIIIIIlIlllllIllllIIllIlIIIII;
import llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lllIIIlIllIIIIlIlIlIIIIIIllllIIIIlIlIllIlIIllIIIlIIlIlIIlllIlIlIllIlIllIllll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llIIIllIIlIllIlIlllllIlllIIlIIlIlIIlIIIIlIlllIlIIIlIIlIlllllIlIllIlIIlIIIIIIlIIllI;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.ClientTickEvent;

public class IIllIIllIIIIIlIIIlllIIlIIIIllIlIIllIIIIIllllIIlIIIlIllllIllIllIllIllIlIlllIllIIllll {
   private static final int[] IIllIIllIIIIIlIIIlllIIlIIIIllIlIIllIIIIIllllIIlIIIlIllllIllIllIllIllIlIlllIllIIllll = new int[]{4300000, 4600000, 4900000, 5200000, 5500000, 5800000, 6100000, 6400000, 6700000, 7000000};
   private static final Pattern lllIlIIllllIIIIIIIIlIlIIlIIIllIIIllIllllIIllllIlIlIlllIllIllIIlIIIllIIIIllIlI = Pattern.compile("\\+(?<gained>[0-9,.]+) (?<skillName>[A-Za-z]+) \\((?<current>[0-9.,]+)%\\)");
   private static final Pattern lllIIlllIlIIIIIlIllIIllIlllIllIlllIIIIIIlllIIIllIlllIllIlIlIlIIIIlIlllIIlI = Pattern.compile("\\+(?<gained>[0-9,.]+) (?<skillName>[A-Za-z]+) (?<progress>\\((?<current>[0-9.,kM]+)/(?<total>[0-9.,kM]+)\\))");
   private static final Pattern llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll = Pattern.compile("\\+(?<gained>[0-9,.]+) (?<skillName>[A-Za-z]+) (?<progress>\\((?<current>[0-9.,kM]+)/(?<total>[0-9.,kM]+)\\))");
   private final llIIIllIIlIllIlIlllllIlllIIlIIlIlIIlIIIIlIlllIlIIIlIIlIlllllIlIllIlIIlIIIIIIlIIllI IllllIIlIllIlIlIlIIIlIIIIIIIIIIIlIllIIIIIlllIlIlIIlllIIlIlIllIllIlIIlIlIIlI = llIIIllIIlIllIlIlllllIlllIIlIIlIlIIlIIIIlIlllIlIIIlIIlIlllllIlIllIlIIlIIIIIIlIIllI.IlIlIIlIlIIlllllllIIlIIIIIllllIIllIIlIlIlllIllllIIllIllIlllllIIlIlIlIIlIlI();
   private long lIlllIIIIllIIIlIIlllllIlIlIlllIlIIllllIIllIlIlIllllIlllIlIIIIIlIIIlIIl = -1L;
   private boolean lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll = false;
   private lllIIIlIllIIIIlIlIlIIIIIIllllIIIIlIlIllIlIIllIIIlIIlIlIIlllIlIlIllIlIllIllll IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI = new lllIIIlIllIIIIlIlIlIIIIIIllllIIIIlIlIllIlIIllIIIlIIlIlIIlllIlIlIllIlIllIllll((lllIIlllIlIIIIIlIllIIllIlllIllIlllIIIIIIlllIIIllIlllIllIlIlIlIIIIlIlllIIlI)null);
   private IIlllIlIIllllIIIIIIlIIllllIllIlIIlIlllIIlIIlllIlIIIIIIIlIlllllIllllIIllIlIIIII lllIIIlIllIIIIlIlIlIIIIIIllllIIIIlIlIllIlIIllIIIlIIlIlIIlllIlIlIllIlIllIllll;

   @SubscribeEvent
   public void llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(lllIllIlllIlIllIlIllIllIlIllIllllIIIlIIIIlllIIIIlIlIIlllIIIIlIIIIlllIIIllllIlllIIIl param1) {
      // $FF: Couldn't be decompiled
   }

   @SubscribeEvent(
      priority = EventPriority.HIGHEST
   )
   public void llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(ClientChatReceivedEvent param1) {
      // $FF: Couldn't be decompiled
   }

   @SubscribeEvent
   public void llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(EntityJoinWorldEvent param1) {
      // $FF: Couldn't be decompiled
   }

   @SubscribeEvent
   public void llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(ClientTickEvent param1) {
      // $FF: Couldn't be decompiled
   }

   public lllIIIlIllIIIIlIlIlIIIIIIllllIIIIlIlIllIlIIllIIIlIIlIlIIlllIlIlIllIlIllIllll llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll() {
      return this.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI;
   }

   static int[] IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI() {
      return IIllIIllIIIIIlIIIlllIIlIIIIllIlIIllIIIIIllllIIlIIIlIllllIllIllIllIllIlIlllIllIIllll;
   }

   private static Exception IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(Exception var0) {
      return var0;
   }
}
