package llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI;

import java.util.HashSet;
import java.util.Set;
import llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lllIlIIllllIIIIIIIIlIlIIlIIIllIIIllIllllIIllllIlIlIlllIllIllIIlIIIllIIIIllIlI;
import llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IlIIIIIlIIlIllIIllIIlIlllIlIlIIlllIllIIlIIIlIIllIIIIIIIIlIlIIlIIlIlIlllIIIlIl;
import llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lIlIIIIIIIIllIIlllIllllllIllIllIIllIIllIIlIIlIIIllIIlIIlIIIIlllIlIllIIIlIlll;
import llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lllIIIlIllIIIIlIlIlIIIIIIllllIIIIlIlIllIlIIllIIIlIIlIlIIlllIlIlIllIlIllIllll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llIIIllIIlIllIlIlllllIlllIIlIIlIlIIlIIIIlIlllIlIIIlIIlIlllllIlIllIlIIlIIIIIIlIIllI;
import llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lllIIIlIllIIIIlIlIlIIIIIIllllIIIIlIlIllIlIIllIIIlIIlIlIIlllIlIlIllIlIllIllll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llllIlIIIIIIIIIIlIIllIlllIIllIIIlllIlllIIlIlIllIlIIIlIllllllIIllIIlIIIlII;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll {
   private static Set<llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll> llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll = new HashSet();
   private static Set<llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll> IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI = new HashSet();

   public static void llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll var0) {
      try {
         if (var0 instanceof lllIlIIllllIIIIIIIIlIlIIlIIIllIIIllIllllIIllllIlIlIlllIllIllIIlIIIllIIIIllIlI) {
            IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.add(var0);
            return;
         }
      } catch (RuntimeException var1) {
         throw IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(var1);
      }

      llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.add(var0);
   }

   @SubscribeEvent(
      priority = EventPriority.HIGHEST,
      receiveCanceled = true
   )
   public void llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(ClientChatReceivedEvent var1) {
      String var2 = var1.message.func_150254_d();
      String var3 = lIlIIIIIIIIllIIlllIllllllIllIllIIllIIllIIlIIlIIIllIIlIIlIIIIlllIlIllIIIlIlll.IllllIIlIllIlIlIlIIIlIIIIIIIIIIIlIllIIIIIlllIlIlIIlllIIlIlIllIllIlIIlIlIIlI(var1.message.func_150254_d());
      boolean var4 = var3.contains(":");

      try {
         if (var1.type == 2) {
            IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.forEach(lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll::lambda$onChat$0);
            return;
         }
      } catch (RuntimeException var5) {
         throw IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(var5);
      }

      llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.forEach(lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll::lambda$onChat$1);
   }

   private static void lambda$onChat$1(ClientChatReceivedEvent var0, String var1, String var2, boolean var3, llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll var4) {
      try {
         var4.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(var0, var1, var2, var3);
      } catch (Exception var7) {
         Exception var5 = var7;

         try {
            if (llllIlIIIIIIIIIIlIIllIlllIIllIIIlllIlllIIlIlIllIlIIIlIllllllIIllIIlIIIlII.IIIIllllIIlllIllIIlIllIIlIllIIIllIIlIlllIlIIlIlllIllllIIlIIlIIlIllIllllIIIllIIIII) {
               IlIIIIIlIIlIllIIllIIlIlllIlIlIIlllIllIIlIIIlIIllIIIIIIIIlIlIIlIIlIlIlllIIIlIl.lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll("An error was caught while attempting to handle chat messages. Please send the log file in support. You can disable this message by turning off §a\"Show Error Messages\"§c, but some features may not work as intended.");
               llIIIllIIlIllIlIlllllIlllIIlIIlIlIIlIIIIlIlllIlIIIlIIlIlllllIlIllIlIIlIIIIIIlIIllI.lllIllIlllIlIllIlIllIllIlIllIllllIIIlIIIIlllIIIIlIlIIlllIIIIlIIIIlllIIIllllIlllIIIl.error(var5.getCause() + " caught at class: " + var4.getClass());
            }
         } catch (Exception var6) {
            throw IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(var6);
         }
      }

   }

   private static void lambda$onChat$0(ClientChatReceivedEvent var0, String var1, String var2, boolean var3, llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll var4) {
      try {
         var4.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(var0, var1, var2, var3);
      } catch (Exception var7) {
         Exception var5 = var7;

         try {
            if (llllIlIIIIIIIIIIlIIllIlllIIllIIIlllIlllIIlIlIllIlIIIlIllllllIIllIIlIIIlII.IIIIllllIIlllIllIIlIllIIlIllIIIllIIlIlllIlIIlIlllIllllIIlIIlIIlIllIllllIIIllIIIII) {
               IlIIIIIlIIlIllIIllIIlIlllIlIlIIlllIllIIlIIIlIIllIIIIIIIIlIlIIlIIlIlIlllIIIlIl.lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll("An error was caught while attempting to handle hotbar messages. Please send the log file in support. You can disable this message by turning off §a\"Show Error Messages\"§c, but some features may not work as intended.");
               llIIIllIIlIllIlIlllllIlllIIlIIlIlIIlIIIIlIlllIlIIIlIIlIlllllIlIllIlIIlIIIIIIlIIllI.lllIllIlllIlIllIlIllIllIlIllIllllIIIlIIIIlllIIIIlIlIIlllIIIIlIIIIlllIIIllllIlllIIIl.error(var5.getCause() + " caught at class: " + var4.getClass());
            }
         } catch (Exception var6) {
            throw IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(var6);
         }
      }

   }

   private static Exception IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(Exception var0) {
      return var0;
   }
}
