package llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll;

import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;

class llIIIllIIlIllIlIlllllIlllIIlIIlIlIIlIIIIlIlllIlIIIlIIlIlllllIlIllIlIIlIIIIIIlIIllI extends llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IllllIIlIllIlIlIlIIIlIIIIIIIIIIIlIllIIIIIlllIlIlIIlllIIlIlIllIllIlIIlIlIIlI implements llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lllIIlllIlIIIIIlIllIIllIlllIllIlllIIIIIIlllIIIllIlllIllIlIlIlIIIIlIlllIIlI {
   private static final Pattern IIllllllIlIIllllIlIlIlllllIIlIlllIlllIIIIIIIlIIlIlllIllllllllllIIIlIIlIIlll = Pattern.compile("§r §r§fPelts: §r§5(?<pelts>[\\d,.]+)§r");
   private static final ItemStack IlIlIIlIlIIlllllllIIlIIIIIllllIIllIIlIlIlllIllllIIllIllIlllllIIlIlIlIIlIlI;
   private static String llIIIllIIlIllIlIlllllIlllIIlIIlIlIIlIIIIlIlllIlIIIlIIlIlllllIlIllIlIIlIIIIIIlIIllI;

   private llIIIllIIlIllIlIlllllIlllIIlIIlIlIIlIIIIlIlllIlIIIlIIlIlllllIlIllIlIIlIIIIIIlIIllI() {
      super("Pelt Display", 0.8F, 0.3F);
      llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll((llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI)this);
   }

   public int llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll() {
      return 20;
   }

   public int IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI() {
      return 100;
   }

   public boolean lllIlIIllllIIIIIIIIlIlIIlIIIllIIIllIllllIIllllIlIlIlllIllIllIIlIIIllIIIIllIlI() {
      // $FF: Couldn't be decompiled
   }

   public void lIlllIIIIllIIIlIIlllllIlIlIlllIlIIllllIIllIlIlIllllIlllIlIIIIIlIIIlIIl() {
      this.lllIIIlIllIIIIlIlIlIIIIIIllllIIIIlIlIllIlIIllIIIlIIlIlIIlllIlIlIllIlIllIllll = 0;
      this.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(IlIlIIlIlIIlllllllIIlIIIIIllllIIllIIlIlIlllIllllIIllIllIlllllIIlIlIlIIlIlI);
      this.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(llIIIllIIlIllIlIlllllIlllIIlIIlIlIIlIIIIlIlllIlIIIlIIlIlllllIlIllIlIIlIIIIIIlIIllI, 20, this.IlIllllIIllllIlllIlllIIIlIllIlIIIlIlllIllIllIIIlIlllIIIIIIlIIIIlIllllIlIIlI.field_71466_p.field_78288_b / 2, 61680);
   }

   public void lllIIlllIlIIIIIlIllIIllIlllIllIlllIIIIIIlllIIIllIlllIllIlIlIlIIIIlIlllIIlI() {
      this.lIlllIIIIllIIIlIIlllllIlIlIlllIlIIllllIIllIlIlIllllIlllIlIIIIIlIIIlIIl();
   }

   public void llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll() {
      try {
         if (Minecraft.func_71410_x() == null) {
            return;
         }
      } catch (RuntimeException var5) {
         throw lllIlIIllllIIIIIIIIlIlIIlIIIllIIIllIllllIIllllIlIlIlllIllIllIIlIIIllIIIIllIlI(var5);
      }

      try {
         if (!llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lllIlIIllllIIIIIIIIlIlIIlIIIllIIIllIllllIIllllIlIlIlllIllIllIIlIIIllIIIIllIlI.lllIlIIllllIIIIIIIIlIlIIlIIIllIIIllIllllIIllllIlIlIlllIllIllIIlIIIllIIIIllIlI.equals("The Farming Islands")) {
            return;
         }
      } catch (RuntimeException var6) {
         throw lllIlIIllllIIIIIIIIlIlIIlIIIllIIIllIllllIIllllIlIlIlllIllIllIIlIIIllIIIIllIlI(var6);
      }

      Iterator var2 = llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IlIlIIlIlIIlllllllIIlIIIIIllllIIllIIlIlIlllIllllIIllIllIlllllIIlIlIlIIlIlI.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll().iterator();

      while(var2.hasNext()) {
         String var3 = (String)var2.next();
         Matcher var1 = IIllllllIlIIllllIlIlIlllllIIlIlllIlllIIIIIIIlIIlIlllIllllllllllIIIlIIlIIlll.matcher(var3);

         try {
            if (var1.find()) {
               llIIIllIIlIllIlIlllllIlllIIlIIlIlIIlIIIIlIlllIlIIIlIIlIlllllIlIllIlIIlIIIIIIlIIllI = "§5" + var1.group("pelts");
            }
         } catch (RuntimeException var4) {
            throw lllIlIIllllIIIIIIIIlIlIIlIIIllIIIllIllllIIllllIlIlIlllIllIllIIlIIIllIIIIllIlI(var4);
         }
      }

   }

   llIIIllIIlIllIlIlllllIlllIIlIIlIlIIlIIIIlIlllIlIIIlIIlIlllllIlIllIlIIlIIIIIIlIIllI(lllIllIlllIlIllIlIllIllIlIllIllllIIIlIIIIlllIIIIlIlIIlllIIIIlIIIIlllIIIllllIlllIIIl var1) {
      this();
   }

   static {
      IlIlIIlIlIIlllllllIIlIIIIIllllIIllIIlIlIlllIllllIIllIllIlllllIIlIlIlIIlIlI = new ItemStack(Items.field_151116_aA);
      llIIIllIIlIllIlIlllllIlllIIlIIlIlIIlIIIIlIlllIlIIIlIIlIlllllIlIllIlIIlIIIIIIlIIllI = "§50";
   }

   private static RuntimeException lllIlIIllllIIIIIIIIlIlIIlIIIllIIIllIllllIIllllIlIlIlllIllIllIIlIIIllIIIIllIlI(RuntimeException var0) {
      return var0;
   }
}
