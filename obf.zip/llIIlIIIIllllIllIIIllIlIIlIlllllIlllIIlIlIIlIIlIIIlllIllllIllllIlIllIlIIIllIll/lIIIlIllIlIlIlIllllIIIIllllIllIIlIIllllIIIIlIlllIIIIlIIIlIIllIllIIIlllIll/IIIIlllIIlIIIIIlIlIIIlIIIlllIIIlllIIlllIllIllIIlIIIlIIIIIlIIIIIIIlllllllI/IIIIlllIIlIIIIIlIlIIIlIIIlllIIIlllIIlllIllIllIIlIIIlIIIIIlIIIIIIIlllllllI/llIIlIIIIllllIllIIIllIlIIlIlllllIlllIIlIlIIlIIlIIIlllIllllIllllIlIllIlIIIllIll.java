package llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI;

import java.io.IOException;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;

class llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll extends llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lllIlIIllllIIIIIIIIlIlIIlIIIllIIIllIllllIIllllIlIlIlllIllIllIIlIIIllIIIIllIlI.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll {
   private llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll() {
   }

   public void func_73869_a(char param1, int param2) throws IOException {
      // $FF: Couldn't be decompiled
   }

   public void func_146280_a(Minecraft var1, int var2, int var3) {
      this.field_146297_k = var1;
      this.field_146296_j = var1.func_175599_af();
      this.field_146289_q = var1.field_71466_p;
      this.field_146294_l = var2;
      this.field_146295_m = var3;
      this.func_73866_w_();
   }

   public void func_73863_a(int var1, int var2, float var3) {
      var1 = (int)((float)var1 / llIIIllIIlIllIlIlllllIlllIIlIIlIlIIlIIIIlIlllIlIIIlIIlIlllllIlIllIlIIlIIIIIIlIIllI.IIIIIIllIlllIIIIlllllIIllIIllllIIlIllIlIlllIIIIlIIIllllllIlIlIlIlIIIIIIlllIll);
      var2 = (int)((float)var2 / llIIIllIIlIllIlIlllllIlllIIlIIlIlIIlIIIIlIlllIlIIIlIIlIlllllIlIllIlIIlIIIIIIlIIllI.IIIIIIllIlllIIIIlllllIIllIIllllIIlIllIlIlllIIIIlIIIllllllIlIlIlIlIIIIIIlllIll);
      GlStateManager.func_179094_E();
      GlStateManager.func_179152_a(llIIIllIIlIllIlIlllllIlllIIlIIlIlIIlIIIIlIlllIlIIIlIIlIlllllIlIllIlIIlIIIIIIlIIllI.IIIIIIllIlllIIIIlllllIIllIIllllIIlIllIlIlllIIIIlIIIllllllIlIlIlIlIIIIIIlllIll, llIIIllIIlIllIlIlllllIlllIIlIIlIlIIlIIIIlIlllIlIIIlIIlIlllllIlIllIlIIlIIIIIIlIIllI.IIIIIIllIlllIIIIlllllIIllIIllllIIlIllIlIlllIIIIlIIIllllllIlIlIlIlIIIIIIlllIll, 1.0F);
      super.func_73863_a(var1, var2, var3);
      GlStateManager.func_179152_a(1.0F / llIIIllIIlIllIlIlllllIlllIIlIIlIlIIlIIIIlIlllIlIIIlIIlIlllllIlIllIlIIlIIIIIIlIIllI.IIIIIIllIlllIIIIlllllIIllIIllllIIlIllIlIlllIIIIlIIIllllllIlIlIlIlIIIIIIlllIll, 1.0F / llIIIllIIlIllIlIlllllIlllIIlIIlIlIIlIIIIlIlllIlIIIlIIlIlllllIlIllIlIIlIIIIIIlIIllI.IIIIIIllIlllIIIIlllllIIllIIllllIIlIllIlIlllIIIIlIIIllllllIlIlIlIlIIIIIIlllIll, 1.0F);
      GlStateManager.func_179121_F();
   }

   llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(IlIIlIlIIIlllIIIIllIIIIIlIIIllllIlllIlllIIIIlIlllIlIlllIIllIIlIllllllIlIllII var1) {
      this();
   }

   private static IOException IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(IOException var0) {
      return var0;
   }

   private static RuntimeException llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(RuntimeException var0) {
      return var0;
   }
}
