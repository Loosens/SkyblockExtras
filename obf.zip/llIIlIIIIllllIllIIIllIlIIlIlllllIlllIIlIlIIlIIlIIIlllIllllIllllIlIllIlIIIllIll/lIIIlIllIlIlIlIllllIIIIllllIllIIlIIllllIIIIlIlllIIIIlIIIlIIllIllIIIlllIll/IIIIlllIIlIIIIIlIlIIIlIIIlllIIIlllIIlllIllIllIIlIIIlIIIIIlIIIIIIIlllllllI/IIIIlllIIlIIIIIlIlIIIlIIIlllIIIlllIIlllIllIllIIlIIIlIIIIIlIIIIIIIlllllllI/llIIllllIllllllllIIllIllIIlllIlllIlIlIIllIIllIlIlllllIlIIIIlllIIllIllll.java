package llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;

public class llIIllllIllllllllIIllIllIIlllIlllIlIlIIllIIllIlIlllllIlIIIIlllIIllIllll extends GuiButton {
   protected final IIIIIIllIlllIIIIlllllIIllIIllllIIlIllIlIlllIIIIlIIIllllllIlIlIlIlIIIIIIlllIll IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI;
   protected float lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll = 1.8F;
   protected float llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll;

   public llIIllllIllllllllIIllIllIIlllIlllIlIlIIllIIllIlIlllllIlIIIIlllIIllIllll(int var1, IIIIIIllIlllIIIIlllllIIllIIllllIIlIllIlIlllIIIIlIIIllllllIlIlIlIlIIIIIIlllIll var2, int var3, int var4) {
      super(var1, var3, var4, 43, 43, "");
      this.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll = this.lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll;
      this.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI = var2;
   }

   public llIIllllIllllllllIIllIllIIlllIlllIlIlIIllIIllIlIlllllIlIIIIlllIIllIllll(int var1, IIIIIIllIlllIIIIlllllIIllIIllllIIlIllIlIlllIIIIlIIIllllllIlIlIlIlIIIIIIlllIll var2, int var3, int var4, boolean var5) {
      super(var1, var3, var4, 16, 16, "");
      this.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll = this.lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll;
      this.lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll = 1.0F;
      this.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll = 1.0F;
      this.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI = var2;
   }

   public void func_146112_a(Minecraft param1, int param2, int param3) {
      // $FF: Couldn't be decompiled
   }

   public boolean func_146116_c(Minecraft param1, int param2, int param3) {
      // $FF: Couldn't be decompiled
   }

   public llIIllllIllllllllIIllIllIIlllIlllIlIlIIllIIllIlIlllllIlIIIIlllIIllIllll llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(boolean var1) {
      this.field_146125_m = var1;
      return this;
   }

   private static RuntimeException IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(RuntimeException var0) {
      return var0;
   }
}
