package llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIllIIllIIIIIlIIIlllIIlIIIIllIlIIllIIIIIllllIIlIIIlIllllIllIllIllIllIlIlllIllIIllll.lllIlIIllllIIIIIIIIlIlIIlIIIllIIIllIllllIIllllIlIlIlllIllIllIIlIIIllIIIIllIlI;

import java.util.regex.Pattern;
import llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lllIIIlIllIIIIlIlIlIIIIIIllllIIIIlIlIllIlIIllIIIlIIlIlIIlllIlIlIllIlIllIllll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lIlllIIIIllIIIlIIlllllIlIlIlllIlIIllllIIllIlIlIllllIlllIlIIIIIlIIIlIIl;
import net.minecraft.crash.CrashReport;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At$Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(
   value = {CrashReport.class},
   priority = 31415
)
public abstract class lllIlIIllllIIIIIIIIlIlIIlIIIllIIIllIllllIIllllIlIlIlllIllIllIIlIIIllIIIIllIlI {
   private static final Pattern BARCODE_PATTERN = Pattern.compile("[Il]{70}.*\\.");
   public boolean sbeCrash = false;
   private boolean using = false;
   @Shadow
   @Final
   private String field_71513_a;

   @Shadow
   public abstract String func_71498_d();

   @Redirect(
      method = {"getCompleteReport"},
      at = @At(
   value = "INVOKE",
   target = "Ljava/lang/StringBuilder;append(Ljava/lang/String;)Ljava/lang/StringBuilder;",
   remap = false,
   ordinal = 0
)
   )
   private StringBuilder completeReportFirst(StringBuilder var1, String var2) {
      var1.append(var2);
      String var3 = this.func_71498_d();

      try {
         if (BARCODE_PATTERN.matcher(var3).find()) {
            this.sbeCrash = true;
            var1.append("This crash may have occurred due to SkyblockExtras. Ask for help in support channels and send this entire log.");
         }

         return var1;
      } catch (RuntimeException var4) {
         throw IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(var4);
      }
   }

   @Inject(
      method = {"getCompleteReport"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void completeReportLast(CallbackInfoReturnable<String> var1) {
      lIlllIIIIllIIIlIIlllllIlIlIlllIlIIllllIIllIlIlIllllIlllIlIIIIIlIIIlIIl.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(var1, this.field_71513_a);
   }

   @Inject(
      method = {"getCompleteReport"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/crash/CrashReport;getCauseStackTraceOrString()Ljava/lang/String;"
)}
   )
   private void completeReportPre(CallbackInfoReturnable<String> var1) {
      this.using = true;
   }

   @Inject(
      method = {"getCompleteReport"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/crash/CrashReport;getCauseStackTraceOrString()Ljava/lang/String;",
   shift = At$Shift.AFTER
)}
   )
   private void completeReportPost(CallbackInfoReturnable<String> var1) {
      this.using = false;
   }

   @Inject(
      method = {"getCauseStackTraceOrString"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void launcherCause(CallbackInfoReturnable<String> param1) {
      // $FF: Couldn't be decompiled
   }

   private static RuntimeException IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(RuntimeException var0) {
      return var0;
   }
}
