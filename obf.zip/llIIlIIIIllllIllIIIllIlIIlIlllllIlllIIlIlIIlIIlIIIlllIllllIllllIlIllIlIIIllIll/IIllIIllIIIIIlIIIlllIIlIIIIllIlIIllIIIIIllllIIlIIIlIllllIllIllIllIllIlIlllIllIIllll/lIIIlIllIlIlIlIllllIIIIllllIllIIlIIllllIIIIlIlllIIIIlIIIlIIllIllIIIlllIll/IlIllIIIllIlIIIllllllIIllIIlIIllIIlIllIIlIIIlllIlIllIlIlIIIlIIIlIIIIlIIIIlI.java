package llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIllIIllIIIIIlIIIlllIIlIIIIllIlIIllIIIIIllllIIlIIIlIllllIllIllIllIllIlIlllIllIIllll.lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll;

import java.util.TreeMap;
import java.util.regex.Pattern;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.Slot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At$Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({GuiContainer.class})
public abstract class IlIllIIIllIlIIIllllllIIllIIlIIllIIlIllIIlIIIlllIlIllIlIlIIIlIIIlIIIIlIIIIlI extends GuiScreen {
   @Shadow
   public Container field_147002_h;
   @Shadow
   private Slot field_147005_v;
   @Shadow
   public Slot field_147006_u;
   @Shadow
   protected int field_147003_i;
   @Shadow
   protected int field_147009_r;
   private int[] slots = null;
   private final Pattern PET_PATTERN = Pattern.compile("§[0-9a-f]\\[Lvl (?<level>\\d+)] §(?<tierColor>[a-f0-9])(?<petName>(\\w|\\s)+)");
   private final Pattern SKIN_PATTERN = Pattern.compile("\\w+ Pet, (?<skin>.+) Skin");
   private boolean isPet;
   private final GuiContainer that = (GuiContainer)this;
   private TreeMap<String, Integer> petMap = new TreeMap();
   private int swapMode;
   private boolean favoriteButtonSelected;
   private boolean petSwapSelected;

   @Inject(
      method = {"initGui()V"},
      at = {@At("RETURN")}
   )
   private void initGui(CallbackInfo param1) {
      // $FF: Couldn't be decompiled
   }

   @Inject(
      method = {"drawScreen"},
      at = {@At("RETURN")}
   )
   private void findStacks(CallbackInfo param1) {
      // $FF: Couldn't be decompiled
   }

   @Inject(
      method = {"drawSlot"},
      cancellable = true,
      at = {@At(
   value = "INVOKE",
   target = "net/minecraft/client/renderer/entity/RenderItem.renderItemAndEffectIntoGUI(Lnet/minecraft/item/ItemStack;II)V"
)}
   )
   private void renderColorMenus(Slot param1, CallbackInfo param2) {
      // $FF: Couldn't be decompiled
   }

   @Inject(
      method = {"drawSlot"},
      cancellable = true,
      at = {@At(
   value = "INVOKE",
   target = "net/minecraft/client/renderer/entity/RenderItem.renderItemAndEffectIntoGUI(Lnet/minecraft/item/ItemStack;II)V"
)}
   )
   private void renderPetOverlay(Slot param1, CallbackInfo param2) {
      // $FF: Couldn't be decompiled
   }

   @Inject(
      method = {"drawScreen(IIF)V"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/gui/inventory/GuiContainer;renderToolTip(Lnet/minecraft/item/ItemStack;II)V",
   shift = At$Shift.BEFORE
)},
      cancellable = true
   )
   private void onTooltipRender(int param1, int param2, float param3, CallbackInfo param4) {
      // $FF: Couldn't be decompiled
   }

   @Inject(
      method = {"handleMouseClick(Lnet/minecraft/inventory/Slot;III)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   protected void handleClick(Slot param1, int param2, int param3, int param4, CallbackInfo param5) {
      // $FF: Couldn't be decompiled
   }

   protected void func_146284_a(GuiButton param1) {
      // $FF: Couldn't be decompiled
   }

   private void petsMenuColor(Slot param1) {
      // $FF: Couldn't be decompiled
   }

   private void choosePetsColor(Slot param1) {
      // $FF: Couldn't be decompiled
   }

   private void swap(int var1, int var2) {
      int var3 = this.slots[var1];
      this.slots[var1] = this.slots[var2];
      this.slots[var2] = var3;
   }

   private static boolean lambda$choosePetsColor$4(String var0) {
      return var0.contains("Equip");
   }

   private static void lambda$actionPerformed$3(GuiButton var0) {
      var0.field_146124_l = true;
   }

   private static void lambda$actionPerformed$2(GuiButton var0) {
      var0.field_146124_l = true;
   }

   private static void lambda$handleClick$1(GuiButton var0) {
      try {
         if (var0.field_146127_k == 123) {
            var0.field_146124_l = true;
         }

      } catch (NumberFormatException var1) {
         throw IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(var1);
      }
   }

   private static void lambda$handleClick$0(GuiButton var0) {
      try {
         if (var0.field_146127_k == 314) {
            var0.field_146124_l = true;
         }

      } catch (NumberFormatException var1) {
         throw IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(var1);
      }
   }

   private static Exception IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(Exception var0) {
      return var0;
   }
}
