package llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIllIIllIIIIIlIIIlllIIlIIIIllIlIIllIIIIIllllIIlIIIlIllllIllIllIllIllIlIlllIllIIllll.lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll;

import net.minecraft.client.gui.GuiIngame;
import net.minecraft.entity.player.EntityPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({GuiIngame.class})
public abstract class lIlIIIIIIIIllIIlllIllllllIllIllIIllIIllIIlIIlIIIllIIlIIlIIIIlllIlIllIIIlIlll {
   @Inject(
      method = {"renderHotbarItem"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/renderer/entity/RenderItem;renderItemAndEffectIntoGUI(Lnet/minecraft/item/ItemStack;II)V"
)}
   )
   private void renderHotbarRarity(int param1, int param2, int param3, float param4, EntityPlayer param5, CallbackInfo param6) {
      // $FF: Couldn't be decompiled
   }

   private static RuntimeException IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(RuntimeException var0) {
      return var0;
   }
}
