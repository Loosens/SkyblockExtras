package llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIllIIllIIIIIlIIIlllIIlIIIIllIlIIllIIIIIllllIIlIIIlIllllIllIllIllIllIlIlllIllIIllll.lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll;

import net.minecraft.client.renderer.entity.RenderLightningBolt;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({RenderLightningBolt.class})
public abstract class llllIIIIlIIIllIIlllIllIllIllIIlIlIIllIIlIIIlIIlIIIllIIIIllIIllIIIlllIIIlIIlIlIIlI {
   @Inject(
      method = {"doRender"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onLightning(CallbackInfo param1) {
      // $FF: Couldn't be decompiled
   }

   private static RuntimeException IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(RuntimeException var0) {
      return var0;
   }
}
