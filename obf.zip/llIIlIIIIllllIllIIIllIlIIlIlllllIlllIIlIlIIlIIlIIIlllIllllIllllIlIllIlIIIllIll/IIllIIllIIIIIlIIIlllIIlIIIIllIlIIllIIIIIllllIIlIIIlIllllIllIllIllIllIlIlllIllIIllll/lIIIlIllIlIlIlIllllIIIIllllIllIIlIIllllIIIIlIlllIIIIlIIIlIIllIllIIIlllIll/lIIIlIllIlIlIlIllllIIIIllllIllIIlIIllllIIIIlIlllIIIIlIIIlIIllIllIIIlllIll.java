package llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIllIIllIIIIIlIIIlllIIlIIIIllIlIIllIIIIIllllIIlIIIlIllllIllIllIllIllIlIlllIllIIllll.lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll;

import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.regex.Pattern;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.gui.inventory.GuiChest;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.inventory.ContainerChest;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ResourceLocation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At$Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({GuiContainer.class})
public abstract class lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll extends GuiScreen {
   private static final String prefix = "§3[SBE] ";
   private static final String[] SLAYER_TYPES = new String[]{"", "Revenant Horror", "Tarantula Broodfather", "Sven Packmaster", "Voidgloom Seraph"};
   private static final Pattern BESTIARY_KILLS_PATTERN = Pattern.compile("(§3)?-*(§f)?-* §b(?<curr>[\\d,.]+)§3/§b(?<max>[\\d,.kMB]+)");
   private static final Pattern BESTIARY_PERCENTAGE_PATTERN = Pattern.compile("§7Progress to Tier .+: §b(?<text>[\\d,.]+%)");
   private static final char section = '§';
   private final GuiContainer that = (GuiContainer)this;
   private static final ResourceLocation CHEST_GUI_TEXTURE = new ResourceLocation("textures/gui/container/generic_54.png");
   private final Pattern PET_PATTERN = Pattern.compile("§[0-9a-f]\\[Lvl (?<level>\\d+)] §(?<tierColor>[a-f0-9])(?<petName>(\\w|\\s)+)");
   private final int WIDTH = 120;
   private final int HEIGHT = 20;
   private final Pattern ENDER_CHEST_PAGE_PATTERN = Pattern.compile("Ender Chest Page (?<page>\\d+)");
   private final Pattern SELECT_ALL_PATTERN = Pattern.compile("Select all the (?<color>(\\w|\\s)+) items!");
   private final Pattern STARTS_WITH_PATTERN = Pattern.compile("What starts with: '(?<letter>\\w)'\\?");
   @Shadow
   protected int field_147003_i;
   @Shadow
   protected int field_147009_r;
   @Shadow
   protected int field_146999_f;
   @Shadow
   public Slot field_147006_u;
   private static llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IlIllllIIllllIlllIlllIIIlIllIlIIIlIlllIllIllIIIlIlllIIIIIIlIIIIlIllllIlIIlI[] searchCriterias;
   private GuiTextField inputFieldx;
   private static Set<String> inventoryItems;
   private static llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IlIIlIlIIIlllIIIIllIIIIIlIIIllllIlllIlllIIIIlIlllIlIlllIIllIIlIllllllIlIllII preview;
   private int mouseX;
   private int mouseY;
   private GuiTextField includeText;
   private GuiTextField excludeText;
   private boolean pfind;
   private int searchBarWidth;
   private int searchBarHeight;
   private static String searchItem;
   private int terminalType = -1;
   private String terminalString;
   private int paneCount = 1;
   private GuiChest guiChest;
   private int counter;
   private int COUNTER_TICK;
   private int experimentType = -1;
   private TreeMap<Integer, Slot> ULTRA_MAP_SLOTS = new TreeMap();
   private Map<Integer, Integer> ULTRA_MAP_STACKS = new HashMap();
   private TreeMap<Integer, Integer> CHRONO_MAP = new TreeMap();
   private List<String> CHRONO_LIST = new ArrayList(Collections.singleton("§4§nPattern:"));
   private boolean chronoReset;
   private boolean chronoClickReset;
   private int chronoCount;
   private boolean lastDisplay;
   private boolean isBazaar;
   private HashMap<Slot, ItemStack> SUPER_MAP = new HashMap();

   @Shadow
   public abstract boolean func_146981_a(Slot var1, int var2, int var3);

   @Shadow
   protected abstract Slot func_146975_c(int var1, int var2);

   @Inject(
      method = {"initGui()V"},
      at = {@At("RETURN")}
   )
   private void initGui(CallbackInfo param1) {
      // $FF: Couldn't be decompiled
   }

   @Inject(
      method = {"drawSlot"},
      cancellable = true,
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/renderer/entity/RenderItem;renderItemOverlayIntoGUI(Lnet/minecraft/client/gui/FontRenderer;Lnet/minecraft/item/ItemStack;IILjava/lang/String;)V"
)}
   )
   private void renderColor(Slot param1, CallbackInfo param2) {
      // $FF: Couldn't be decompiled
   }

   @Inject(
      method = {"drawSlot"},
      cancellable = true,
      at = {@At(
   value = "INVOKE",
   target = "net/minecraft/client/renderer/entity/RenderItem.renderItemAndEffectIntoGUI(Lnet/minecraft/item/ItemStack;II)V"
)}
   )
   private void renderColorMenus(Slot var1, CallbackInfo var2) {
      try {
         llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IllllIIlIllIlIlIlIIIlIIIIIIIIIIIlIllIIIIIlllIlIlIIlllIIlIlIllIllIlIIlIlIIlI.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(var2, var1, this.that);
         if (!(this.that instanceof GuiChest) || this.experimentType == -1) {
            return;
         }
      } catch (Exception var5) {
         throw IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(var5);
      }

      try {
         this.colorExperimentSlots(var1, var2);
      } catch (Exception var4) {
      }

   }

   @Inject(
      method = {"handleMouseClick(Lnet/minecraft/inventory/Slot;III)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   protected void handleClick(Slot param1, int param2, int param3, int param4, CallbackInfo param5) {
      // $FF: Couldn't be decompiled
   }

   @Inject(
      method = {"mouseClicked(III)V"},
      at = {@At("RETURN")}
   )
   private void mouseClicked(int param1, int param2, int param3, CallbackInfo param4) {
      // $FF: Couldn't be decompiled
   }

   @Inject(
      method = {"drawScreen(IIF)V"},
      at = {@At(
   value = "INVOKE",
   target = "net/minecraft/client/gui/GuiScreen.drawScreen(IIF)V",
   shift = At$Shift.BEFORE
)}
   )
   private void drawSearchBar(int param1, int param2, float param3, CallbackInfo param4) {
      // $FF: Couldn't be decompiled
   }

   @Inject(
      method = {"drawScreen(IIF)V"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/gui/inventory/GuiContainer;renderToolTip(Lnet/minecraft/item/ItemStack;II)V",
   shift = At$Shift.BEFORE
)},
      cancellable = true
   )
   private void onTooltipRender(int param1, int param2, float param3, CallbackInfo param4) {
      // $FF: Couldn't be decompiled
   }

   @Inject(
      method = {"keyTyped(CI)V"},
      cancellable = true,
      at = {@At("HEAD")}
   )
   private void keyTyped(char param1, int param2, CallbackInfo param3) throws IOException {
      // $FF: Couldn't be decompiled
   }

   @Inject(
      method = {"drawScreen"},
      at = {@At("RETURN")}
   )
   private void drawPreviews(int param1, int param2, float param3, CallbackInfo param4) {
      // $FF: Couldn't be decompiled
   }

   private void drawPreview(llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI.IlIIlIlIIIlllIIIIllIIIIIlIIIllllIlllIlllIIIIlIlllIlIlllIIllIIlIllllllIlIllII param1) {
      // $FF: Couldn't be decompiled
   }

   private void color(Slot var1, int var2, int var3, int var4, int var5) {
      GlStateManager.func_179140_f();
      GlStateManager.func_179097_i();
      int var6 = var1.field_75223_e;
      int var7 = var1.field_75221_f;
      GlStateManager.func_179135_a(true, true, true, false);
      int var8 = (new Color(var2, var3, var4, var5)).getRGB();
      this.func_73733_a(var6, var7, var6 + 16, var7 + 16, var8, var8);
      GlStateManager.func_179135_a(true, true, true, true);
      GlStateManager.func_179145_e();
      GlStateManager.func_179126_j();
   }

   private void color(Slot var1, int var2) {
      GlStateManager.func_179140_f();
      GlStateManager.func_179097_i();
      int var3 = var1.field_75223_e;
      int var4 = var1.field_75221_f;
      GlStateManager.func_179135_a(true, true, true, false);
      this.func_73733_a(var3, var4, var3 + 16, var4 + 16, var2, var2);
      GlStateManager.func_179135_a(true, true, true, true);
      GlStateManager.func_179145_e();
      GlStateManager.func_179126_j();
   }

   private void highlightSellItems(Slot param1, CallbackInfo param2) {
      // $FF: Couldn't be decompiled
   }

   private void colorTerminalSlots(Slot param1, CallbackInfo param2) {
      // $FF: Couldn't be decompiled
   }

   private void handleTerminalClicks(ContainerChest param1, int param2, int param3, Slot param4, CallbackInfo param5) {
      // $FF: Couldn't be decompiled
   }

   private void handleExperimentClicks(ContainerChest param1, int param2, int param3, Slot param4, CallbackInfo param5) {
      // $FF: Couldn't be decompiled
   }

   private void analyzeSlots(List<Slot> param1) {
      // $FF: Couldn't be decompiled
   }

   private void removeSlots(List<Slot> param1) {
      // $FF: Couldn't be decompiled
   }

   private void colorExperimentSlots(Slot param1, CallbackInfo param2) {
      // $FF: Couldn't be decompiled
   }

   private void drawBestiaryInfo(Slot param1) {
      // $FF: Couldn't be decompiled
   }

   private void drawPfNumbers(Slot var1) {
      if (var1.func_75216_d()) {
         try {
            ItemStack var2 = var1.func_75211_c();
            if (!var2.func_82833_r().contains("Party")) {
               return;
            }

            List var3 = llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lIlIIIIIIIIllIIlllIllllllIllIllIIllIIllIIlIIlIIIllIIlIIlIIIIlllIlIllIIIlIlll.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(var2);
            int var4 = 0;
            Iterator var5 = var3.iterator();

            while(var5.hasNext()) {
               String var6 = (String)var5.next();

               try {
                  if (var6.contains("§8 Empty")) {
                     ++var4;
                  }
               } catch (Exception var7) {
                  throw IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(var7);
               }
            }

            GlStateManager.func_179094_E();
            GlStateManager.func_179109_b(0.0F, 0.0F, 299.0F);
            this.field_146297_k.field_71466_p.func_175063_a(String.valueOf(5 - var4), (float)(var1.field_75223_e + 19 - 2 - this.field_146297_k.field_71466_p.func_78256_a(String.valueOf(5 - var4))), (float)(var1.field_75221_f + 6 + 3), 16777215);
            GlStateManager.func_179121_F();
         } catch (Exception var8) {
         }
      }

   }

   @Unique
   private String getUnalteredName(ItemStack var1) {
      NBTTagCompound var2 = var1.func_77978_p();
      String var3 = "";

      try {
         if (var2 == null || !var2.func_150297_b("display", 10)) {
            return var3;
         }
      } catch (RuntimeException var5) {
         throw IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(var5);
      }

      NBTTagCompound var4 = var2.func_74775_l("display");
      if (var4.func_150297_b("Name", 8)) {
         var3 = var4.func_74779_i("Name");
      }

      return var3;
   }

   private static boolean lambda$handleClick$0(String var0) {
      return var0.contains("Click to reroll");
   }

   private static Exception IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(Exception var0) {
      return var0;
   }
}
