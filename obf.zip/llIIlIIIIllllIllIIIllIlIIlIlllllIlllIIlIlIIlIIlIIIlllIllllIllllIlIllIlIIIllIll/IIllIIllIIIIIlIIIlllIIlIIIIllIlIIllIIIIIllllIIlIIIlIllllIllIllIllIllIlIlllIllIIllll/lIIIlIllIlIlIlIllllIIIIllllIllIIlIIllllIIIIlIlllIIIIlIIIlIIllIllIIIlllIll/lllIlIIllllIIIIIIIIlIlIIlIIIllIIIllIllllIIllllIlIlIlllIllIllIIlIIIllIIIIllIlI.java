package llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIllIIllIIIIIlIIIlllIIlIIIIllIlIIllIIIIIllllIIlIIIlIllllIllIllIllIllIlIlllIllIIllll.lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll;

import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderEntityItem;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At$Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({RenderEntityItem.class})
public abstract class lllIlIIllllIIIIIIIIlIlIIlIIIllIIIllIllllIIllllIlIlIlllIllIllIIlIIIllIIIIllIlI {
   @Inject(
      method = {"doRender(Lnet/minecraft/entity/item/EntityItem;DDDFF)V"},
      at = {@At(
   value = "INVOKE",
   target = "net/minecraft/client/renderer/GlStateManager.pushMatrix()V",
   shift = At$Shift.AFTER,
   ordinal = 1
)}
   )
   private void renderBigItems(EntityItem var1, double var2, double var4, double var6, float var8, float var9, CallbackInfo var10) {
      try {
         label68: {
            try {
               if (!llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lllIIIlIllIIIIlIlIlIIIIIIllllIIIIlIlIllIlIIllIIIlIIlIlIIlllIlIlIllIlIllIllll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llllIlIIIIIIIIIIlIIllIlllIIllIIIlllIlllIIlIlIllIlIIIlIllllllIIllIIlIIIlII.IlIlIIllIlIIIIIllIIIllIIlIIllIlIlIIIIllIlllIlIIIIIlllllllIlIIllIIIlllIII || !var1.func_92059_d().func_77942_o()) {
                  break label68;
               }
            } catch (Exception var17) {
               throw IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(var17);
            }

            NBTTagCompound var11 = var1.func_92059_d().func_77978_p();
            NBTTagList var12 = var11.func_74775_l("display").func_150295_c("Lore", 8);
            float var13 = (float)llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lllIIIlIllIIIIlIlIlIIIIIIllllIIIIlIlIllIlIIllIIIlIIlIlIIlllIlIlIllIlIllIllll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llllIlIIIIIIIIIIlIIllIlllIIllIIIlllIlllIIlIlIllIlIIIlIllllllIIllIIlIIIlII.IIlIIlIllIlIIlIIlIllllllIlIIIIIlIIIllIIlIlIIlIlIlIIIllIlIIlIIllIIIIlIIIlI / 100.0F;
            float var14 = 4.0F;
            if (llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lllIIIlIllIIIIlIlIlIIIIIIllllIIIIlIlIllIlIIllIIIlIIlIlIIlllIlIlIllIlIllIllll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llllIlIIIIIIIIIIlIIllIlllIIllIIIlllIlllIIlIlIllIlIIIlIllllllIIllIIlIIIlII.IIllIllIIlIIlIIIIIIllIllIlIlllIIIlllIIllllIllIIIllllIlIIllllIIIllIIIlII) {
               for(int var15 = 0; var15 < var12.func_74745_c(); ++var15) {
                  String var16 = var12.func_150307_f(var15);

                  label56: {
                     try {
                        if (!var16.contains("MYTHIC") && !var16.contains("SPECIAL")) {
                           break label56;
                        }
                     } catch (Exception var18) {
                        throw IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(var18);
                     }

                     var14 = 10.0F;
                     continue;
                  }

                  if (var16.contains("LEGENDARY")) {
                     var14 = 7.0F;
                  } else if (var16.contains("EPIC")) {
                     var14 = 3.0F;
                  } else if (var16.contains("RARE")) {
                     var14 = 1.5F;
                  } else if (var16.contains("UNCOMMON")) {
                     var14 = 1.2F;
                  }
               }
            }

            GlStateManager.func_179152_a(var13 * var14, var13 * var14, var13 * var14);
         }

         GlStateManager.func_179137_b(0.0D, 0.15D, 0.0D);
      } catch (Exception var19) {
      }

   }

   private static Exception IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(Exception var0) {
      return var0;
   }
}
