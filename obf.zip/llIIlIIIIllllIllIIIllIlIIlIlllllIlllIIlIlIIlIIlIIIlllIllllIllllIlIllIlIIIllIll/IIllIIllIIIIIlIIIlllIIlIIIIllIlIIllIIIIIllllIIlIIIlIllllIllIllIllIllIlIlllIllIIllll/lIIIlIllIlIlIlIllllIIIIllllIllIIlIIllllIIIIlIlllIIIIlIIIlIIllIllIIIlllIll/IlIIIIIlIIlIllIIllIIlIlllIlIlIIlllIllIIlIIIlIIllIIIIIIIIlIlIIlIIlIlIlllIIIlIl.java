package llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIllIIllIIIIIlIIIlllIIlIIIIllIlIIllIIIIIllllIIlIIIlIllllIllIllIllIllIlIlllIllIIllll.lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll;

import java.awt.Color;
import net.minecraft.client.particle.EntityFX;
import net.minecraft.client.particle.EntityFootStepFX;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At$Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({EntityFootStepFX.class})
public abstract class IlIIIIIlIIlIllIIllIIlIlllIlIlIIlllIllIIlIIIlIIllIIIIIIIIlIlIIlIIlIlIlllIIIlIl extends EntityFX {
   protected IlIIIIIlIIlIllIIllIIlIlllIlIlIIlllIllIIlIIIlIIllIIIIIIIIlIlIIlIIlIlIlllIIIlIl(World var1, double var2, double var4, double var6) {
      super(var1, var2, var4, var6);
   }

   @Inject(
      method = {"renderParticle"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/renderer/Tessellator;draw()V",
   shift = At$Shift.BEFORE
)}
   )
   private void render(WorldRenderer var1, Entity var2, float var3, float var4, float var5, float var6, float var7, float var8, CallbackInfo var9) {
      try {
         if (!llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lllIIIlIllIIIIlIlIlIIIIIIllllIIIIlIlIllIlIIllIIIlIIlIlIIlllIlIlIllIlIllIllll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llllIlIIIIIIIIIIlIIllIlllIIllIIIlllIlllIIlIlIllIlIIIlIllllllIIllIIlIIIlII.llIllllIIlIlIlIllIIlIIlIIlIIlllIIllllllIIlIlllIlIlIIllIIIlIIIIlIlIlIll || !llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lllIlIIllllIIIIIIIIlIlIIlIIIllIIIllIllllIIllllIlIlIlllIllIllIIlIIIllIIIIllIlI.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll) {
            return;
         }
      } catch (RuntimeException var17) {
         throw IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(var17);
      }

      GlStateManager.func_179140_f();
      float var10 = (float)(this.field_70165_t - EntityFootStepFX.field_70556_an);
      float var11 = (float)(this.field_70163_u - EntityFootStepFX.field_70554_ao);
      float var12 = (float)(this.field_70161_v - EntityFootStepFX.field_70555_ap);
      Color var13 = Color.red;
      float var14 = (float)var13.getRed() / 255.0F;
      float var15 = (float)var13.getGreen() / 255.0F;
      float var16 = (float)var13.getBlue() / 255.0F;
      var1.func_181662_b((double)(var10 - 0.125F), (double)var11, (double)(var12 + 0.125F)).func_181673_a(0.0D, 1.0D).func_181666_a(var14, var15, var16, 1.0F).func_181675_d();
      var1.func_181662_b((double)(var10 + 0.125F), (double)var11, (double)(var12 + 0.125F)).func_181673_a(1.0D, 1.0D).func_181666_a(var14, var15, var16, 1.0F).func_181675_d();
      var1.func_181662_b((double)(var10 + 0.125F), (double)var11, (double)(var12 - 0.125F)).func_181673_a(1.0D, 0.0D).func_181666_a(var14, var15, var16, 1.0F).func_181675_d();
      var1.func_181662_b((double)(var10 - 0.125F), (double)var11, (double)(var12 - 0.125F)).func_181673_a(0.0D, 0.0D).func_181666_a(var14, var15, var16, 1.0F).func_181675_d();
   }

   private static RuntimeException IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(RuntimeException var0) {
      return var0;
   }
}
