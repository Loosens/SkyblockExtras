package llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIllIIllIIIIIlIIIlllIIlIIIIllIlIIllIIIIIllllIIlIIIlIllllIllIllIllIllIlIlllIllIIllll.lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll;

import net.minecraft.client.particle.EffectRenderer;
import net.minecraft.client.particle.EntityFX;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({EffectRenderer.class})
public abstract class llIIllllIllllllllIIllIllIIlllIlllIlIlIIllIIllIlIlllllIlIIIIlllIIllIllll {
   private long lastPing = 0L;

   @Inject(
      method = {"spawnEffectParticle"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void spawnEffectParticle(int param1, double param2, double param4, double param6, double param8, double param10, double param12, int[] param14, CallbackInfoReturnable<EntityFX> param15) {
      // $FF: Couldn't be decompiled
   }

   @Inject(
      method = {"addBlockDestroyEffects"},
      cancellable = true,
      at = {@At("HEAD")}
   )
   private void addBlockDestroyEffects(CallbackInfo var1) {
      try {
         if (llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lllIIIlIllIIIIlIlIlIIIIIIllllIIIIlIlIllIlIIllIIIlIIlIlIIlllIlIlIllIlIllIllll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llllIlIIIIIIIIIIlIIllIlllIIllIIIlllIlllIIlIlIllIlIIIlIllllllIIllIIlIIIlII.llllIlllIllIIIIlIlIIIIllIllIllllllIIllIllllIlIllIIllIIlIIIIllIlIIlIIlIIIllIlIlIl) {
            var1.cancel();
         }

      } catch (RuntimeException var2) {
         throw IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(var2);
      }
   }

   @Inject(
      method = {"addBlockHitEffects(Lnet/minecraft/util/BlockPos;Lnet/minecraft/util/EnumFacing;)V"},
      cancellable = true,
      at = {@At("HEAD")}
   )
   private void addBlockHitEffects(CallbackInfo var1) {
      try {
         if (llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lllIIIlIllIIIIlIlIlIIIIIIllllIIIIlIlIllIlIIllIIIlIIlIlIIlllIlIlIllIlIllIllll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llllIlIIIIIIIIIIlIIllIlllIIllIIIlllIlllIIlIlIllIlIIIlIllllllIIllIIlIIIlII.llllIlllIllIIIIlIlIIIIllIllIllllllIIllIllllIlIllIIllIIlIIIIllIlIIlIIlIIIllIlIlIl) {
            var1.cancel();
         }

      } catch (RuntimeException var2) {
         throw IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(var2);
      }
   }

   private static Exception IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(Exception var0) {
      return var0;
   }
}
