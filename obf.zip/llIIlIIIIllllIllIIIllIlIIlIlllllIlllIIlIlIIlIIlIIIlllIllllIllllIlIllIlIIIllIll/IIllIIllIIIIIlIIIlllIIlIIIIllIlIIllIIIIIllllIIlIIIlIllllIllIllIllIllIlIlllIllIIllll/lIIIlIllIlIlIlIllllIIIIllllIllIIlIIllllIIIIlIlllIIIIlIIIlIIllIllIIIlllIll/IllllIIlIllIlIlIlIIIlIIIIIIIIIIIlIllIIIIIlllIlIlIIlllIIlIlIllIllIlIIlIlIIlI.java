package llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIllIIllIIIIIlIIIlllIIlIIIIllIlIIllIIIIIllllIIlIIIlIllllIllIllIllIllIlIlllIllIIllll.lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll;

import java.util.ConcurrentModificationException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.client.gui.FontRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin({FontRenderer.class})
public abstract class IllllIIlIllIlIlIlIIIlIIIIIIIIIIIlIllIIIIIlllIlIlIIlllIIlIlIllIllIlIIlIlIIlI {
   @Shadow
   private float field_78291_n;
   private static final Pattern COMPLEX_PATTERN = Pattern.compile("(?<rank>(§[a-f0-9r])*(§[a-f0-9])\\[MVP(§[a-f0-9r])*(§[a-f0-9r])\\+{1,2}(§[a-f0-9r])*(§[a-f0-9r])]) ComplexOrigin");
   private final char SECTION = 167;

   @Shadow
   public abstract String func_78269_a(String var1, int var2);

   @Shadow
   protected abstract void func_111272_d();

   @ModifyVariable(
      method = {"renderString(Ljava/lang/String;FFIZ)I"},
      at = @At("HEAD"),
      argsOnly = true
   )
   private String renderString(String param1) {
      // $FF: Couldn't be decompiled
   }

   private String replacePrefix(String var1, String var2, String var3) {
      String var4 = "(?:(?:\\u00a7[0-9a-fbr])\\B(?:(?i)" + var2 + ")\\b)|(?:\\u00a7[rb](?i)" + var2 + "\\u00a7r)|\\b(?i)" + var2 + "\\b";
      Pattern var5 = Pattern.compile("(?:.*\\B(?:(?<color>\\u00a7[0-9a-fbr])(?i)" + var2 + ")\\b.*)");
      Matcher var6 = var5.matcher(var1);

      try {
         if (var6.matches()) {
            return var1.replaceAll(var4, '§' + var3 + var2 + var6.group("color"));
         }
      } catch (ConcurrentModificationException var7) {
         throw IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(var7);
      }

      return var1.replaceAll(var4, '§' + var3 + var2 + '§' + "r");
   }

   private String replaceName(String var1, String var2, String var3) {
      String var4 = "(?:(?:\\u00a7[0-9a-fbr])\\B(?:(?i)" + var2 + ")\\b)|(?:\\u00a7[rb](?i)" + var2 + "\\u00a7r)|\\b(?i)" + var2 + "\\b";
      Pattern var5 = Pattern.compile("(?:.*\\B(?:(?<color>\\u00a7[0-9a-fbr])(?i)" + var2 + ")\\b.*)");
      Matcher var6 = var5.matcher(var1);

      try {
         if (var6.matches()) {
            return var1.replaceAll(var4, var3 + var6.group("color"));
         }
      } catch (ConcurrentModificationException var7) {
         throw IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(var7);
      }

      return var1.replaceAll(var4, var3);
   }

   private static ConcurrentModificationException IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(ConcurrentModificationException var0) {
      return var0;
   }
}
