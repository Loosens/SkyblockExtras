package llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIllIIllIIIIIlIIIlllIIlIIIIllIlIIllIIIIIllllIIlIIIlIllllIllIllIllIllIlIlllIllIIllll.lllIIlllIlIIIIIlIllIIllIlllIllIlllIIIIIIlllIIIllIlllIllIlIlIlIIIIlIlllIIlI;

import java.util.List;
import java.util.regex.Pattern;
import llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lIlIIIIIIIIllIIlllIllllllIllIllIIllIIllIIlIIlIIIllIIlIIlIIIIlllIlIllIIIlIlll;
import llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lllIIIlIllIIIIlIlIlIIIIIIllllIIIIlIlIllIlIIllIIIlIIlIlIIlllIlIlIllIlIllIllll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llllIlIIIIIIIIIIlIIllIlllIIllIIIlllIlllIIlIlIllIlIIIlIllllllIIllIIlIIIlII;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({ItemStack.class})
public abstract class lllIlIIllllIIIIIIIIlIlIIlIIIllIIIllIllllIIllllIlIlIlllIllIllIIlIIIllIIIIllIlI {
   @Shadow
   private NBTTagCompound field_77990_d;
   @Shadow
   private Item field_151002_e;
   private final ItemStack that = (ItemStack)this;
   private static final NBTTagCompound RED_SKULL_TEXTURE = lIlIIIIIIIIllIIlllIllllllIllIllIIllIIllIIlIIlIIIllIIlIIlIIIIlllIlIllIIIlIlll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll("eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvY2I4NTJiYTE1ODRkYTllNTcxNDg1OTk5NTQ1MWU0Yjk0NzQ4YzRkZDYzYWU0NTQzYzE1ZjlmOGFlYzY1YzgifX19");
   private final Pattern NUMBERS_PATTERN = Pattern.compile("\\d{1,2}");
   private final Pattern ENDER_CHEST_PAGE_PATTERN = Pattern.compile("Ender Chest Page (?<page>\\d+)");

   @Shadow
   public abstract String func_82833_r();

   @Shadow
   public abstract List<String> func_82840_a(EntityPlayer var1, boolean var2);

   @Shadow
   public abstract boolean func_111282_a(EntityPlayer var1, EntityLivingBase var2);

   @ModifyVariable(
      method = {"getDisplayName"},
      at = @At("STORE")
   )
   private String setDisplayName(String param1) {
      // $FF: Couldn't be decompiled
   }

   @Inject(
      method = {"isItemDamaged"},
      cancellable = true,
      at = {@At("HEAD")}
   )
   private void isItemDamaged(CallbackInfoReturnable<Boolean> var1) {
      try {
         if (llllIlIIIIIIIIIIlIIllIlllIIllIIIlllIlllIIlIlIllIlIIIlIllllllIIllIIlIIIlII.IIlllllIllIlllllIIIIIlIllIIlIIlIIllIIllIlllIlIllIllIIIlIIIIlIlIIllIIlllIIIlIl) {
            var1.setReturnValue(false);
         }

      } catch (RuntimeException var2) {
         throw IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(var2);
      }
   }

   @Inject(
      method = {"isItemEnchanted()Z"},
      cancellable = true,
      at = {@At("HEAD")}
   )
   private void onSkyblockEnchantRender(CallbackInfoReturnable<Boolean> param1) {
      // $FF: Couldn't be decompiled
   }

   @Inject(
      method = {"getTooltip(Lnet/minecraft/entity/player/EntityPlayer;Z)Ljava/util/List;"},
      cancellable = true,
      at = {@At("HEAD")}
   )
   public void getTooltip(EntityPlayer param1, boolean param2, CallbackInfoReturnable<List<?>> param3) {
      // $FF: Couldn't be decompiled
   }

   @Inject(
      method = {"getTagCompound"},
      cancellable = true,
      at = {@At("HEAD")}
   )
   private void getTagCompound(CallbackInfoReturnable<NBTTagCompound> param1) {
      // $FF: Couldn't be decompiled
   }

   private String getUnalteredName() {
      String var1 = "";

      try {
         if (this.field_77990_d == null || !this.field_77990_d.func_150297_b("display", 10)) {
            return var1;
         }
      } catch (RuntimeException var3) {
         throw IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(var3);
      }

      NBTTagCompound var2 = this.field_77990_d.func_74775_l("display");
      if (var2.func_150297_b("Name", 8)) {
         var1 = var2.func_74779_i("Name");
      }

      return var1;
   }

   private static RuntimeException IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(RuntimeException var0) {
      return var0;
   }
}
