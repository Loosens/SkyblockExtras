package llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IIllIIllIIIIIlIIIlllIIlIIIIllIlIIllIIIIIllllIIlIIIlIllllIllIllIllIllIlIlllIllIIllll.lllIIlllIlIIIIIlIllIIllIlllIllIlllIIIIIIlllIIIllIlllIllIlIlIlIIIIlIlllIIlI;

import net.minecraft.block.state.IBlockState;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.common.MinecraftForge;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({World.class})
public abstract class lIlllIIIIllIIIlIIlllllIlIlIlllIlIIllllIIllIlIlIllllIlllIlIIIIIlIIIlIIl {
   @Shadow
   public abstract IBlockState func_180495_p(BlockPos var1);

   @Inject(
      method = {"setBlockState(Lnet/minecraft/util/BlockPos;Lnet/minecraft/block/state/IBlockState;I)Z"},
      at = {@At("HEAD")}
   )
   private void onBlockUpdate(BlockPos var1, IBlockState var2, int var3, CallbackInfoReturnable<Boolean> var4) {
      IBlockState var5 = this.func_180495_p(var1);

      try {
         if (var2 != var5) {
            MinecraftForge.EVENT_BUS.post(new llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IllllIIlIllIlIlIlIIIlIIIIIIIIIIIlIllIIIIIlllIlIlIIlllIIlIlIllIllIlIIlIlIIlI.lIlllIIIIllIIIlIIlllllIlIlIlllIlIIllllIIllIlIlIllllIlllIlIIIIIlIIIlIIl(var1, var5, var2, var3));
         }

      } catch (RuntimeException var6) {
         throw IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(var6);
      }
   }

   private static RuntimeException IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(RuntimeException var0) {
      return var0;
   }
}
