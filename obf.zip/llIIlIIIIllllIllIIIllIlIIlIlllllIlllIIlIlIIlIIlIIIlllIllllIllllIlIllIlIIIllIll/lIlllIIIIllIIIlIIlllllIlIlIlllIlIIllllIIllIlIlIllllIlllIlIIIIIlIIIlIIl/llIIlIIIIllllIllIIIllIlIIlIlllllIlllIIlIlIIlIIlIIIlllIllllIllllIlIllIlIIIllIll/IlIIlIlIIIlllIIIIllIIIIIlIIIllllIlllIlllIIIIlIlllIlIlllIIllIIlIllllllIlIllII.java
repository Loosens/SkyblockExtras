package llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lIlllIIIIllIIIlIIlllllIlIlIlllIlIIllllIIllIlIlIllllIlllIlIIIIIlIIIlIIl.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll;

import java.util.HashMap;

final class IlIIlIlIIIlllIIIIllIIIIIlIIIllllIlllIlllIIIIlIlllIlIlllIIllIIlIllllllIlIllII extends HashMap<Integer, Integer> {
   IlIIlIlIIIlllIIIIllIIIIIlIIIllllIlllIlllIIIIlIlllIlIlllIIllIIlIllllllIlIllII() {
      this.put(0, 0);
      this.put(5920, 1);
      this.put(6953, 2);
      this.put(61625, 3);
      this.put(15129, 4);
      this.put(11072, 5);
      this.put(12997, 6);
      this.put(22265, 7);
      this.put(45008, 8);
      this.put(12017, 9);
   }
}
