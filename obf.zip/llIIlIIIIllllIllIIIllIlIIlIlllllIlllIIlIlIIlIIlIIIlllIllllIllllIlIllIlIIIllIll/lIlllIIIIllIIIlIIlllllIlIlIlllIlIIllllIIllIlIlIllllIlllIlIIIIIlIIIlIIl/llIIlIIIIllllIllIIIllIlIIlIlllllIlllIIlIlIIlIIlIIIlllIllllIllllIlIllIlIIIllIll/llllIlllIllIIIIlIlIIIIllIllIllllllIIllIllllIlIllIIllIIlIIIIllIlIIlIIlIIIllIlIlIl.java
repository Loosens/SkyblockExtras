package llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lIlllIIIIllIIIlIIlllllIlIlIlllIlIIllllIIllIlIlIllllIlllIlIIIIIlIIIlIIl.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll;

import net.minecraft.util.EnumFacing;

// $FF: synthetic class
class llllIlllIllIIIIlIlIIIIllIllIllllllIIllIllllIlIllIIllIIlIIIIllIlIIlIIlIIIllIlIlIl {
   static final int[] llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll = new int[EnumFacing.values().length];

   static {
      try {
         llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll[EnumFacing.SOUTH.ordinal()] = 1;
      } catch (NoSuchFieldError var3) {
      }

      try {
         llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll[EnumFacing.NORTH.ordinal()] = 2;
      } catch (NoSuchFieldError var2) {
      }

      try {
         llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll[EnumFacing.WEST.ordinal()] = 3;
      } catch (NoSuchFieldError var1) {
      }

   }
}
