package llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lIlllIIIIllIIIlIIlllllIlIlIlllIlIIllllIIllIlIlIllllIlllIlIIIIIlIIIlIIl.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll;

import java.util.Objects;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;

public class lIIIlIlllllIIlIlIIIlIIIIlIlIIIlllIIlIllIlllIIlIllllllllIlIllIIllIIIIIIl implements lllIlIIllllIIIIIIIIlIlIIlIIIllIIIllIllllIIllllIlIlIlllIllIllIIlIIIllIIIIllIlI {
   private final BlockPos llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll;
   private final lllIlIIllllIIIIIIIIlIlIIlIIIllIIIllIllllIIllllIlIlIlllIllIllIIlIIIllIIIIllIlI[][] lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll;
   private final int IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI;
   private final int lllIlIIllllIIIIIIIIlIlIIlIIIllIIIllIllllIIllllIlIlIlllIllIllIIlIIIllIIIIllIlI;

   public boolean llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(World var1) {
      return false;
   }

   public lllIlIIllllIIIIIIIIlIlIIlIIIllIIIllIllllIIllllIlIlIlllIllIllIIlIIIllIIIIllIlI[] llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll() {
      // $FF: Couldn't be decompiled
   }

   public BlockPos lllIlIIllllIIIIIIIIlIlIIlIIIllIIIllIllllIIllllIlIlIlllIllIllIIlIIIllIIIIllIlI() {
      return this.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll;
   }

   public int lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll() {
      return this.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI;
   }

   public int IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI() {
      return this.lllIlIIllllIIIIIIIIlIlIIlIIIllIIIllIllllIIllllIlIlIlllIllIllIIlIIIllIIIIllIlI;
   }

   lIIIlIlllllIIlIlIIIlIIIIlIlIIIlllIIlIllIlllIIlIllllllllIlIllIIllIIIIIIl(BlockPos var1, int var2, int var3, lllIlIIllllIIIIIIIIlIlIIlIIIllIIIllIllllIIllllIlIlIlllIllIllIIlIIIllIIIIllIlI[][] var4) {
      this.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll = var1;
      this.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI = var2;
      this.lllIlIIllllIIIIIIIIlIlIIlIIIllIIIllIllllIIllllIlIlIlllIllIllIIlIIIllIIIIllIlI = var3;
      this.lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll = var4;
   }

   public boolean equals(Object param1) {
      // $FF: Couldn't be decompiled
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll, this.lIIIlIllIlIlIlIllllIIIIllllIllIIlIIllllIIIIlIlllIIIIlIIIlIIllIllIIIlllIll(), this.IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI()});
   }

   private static RuntimeException IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(RuntimeException var0) {
      return var0;
   }
}
