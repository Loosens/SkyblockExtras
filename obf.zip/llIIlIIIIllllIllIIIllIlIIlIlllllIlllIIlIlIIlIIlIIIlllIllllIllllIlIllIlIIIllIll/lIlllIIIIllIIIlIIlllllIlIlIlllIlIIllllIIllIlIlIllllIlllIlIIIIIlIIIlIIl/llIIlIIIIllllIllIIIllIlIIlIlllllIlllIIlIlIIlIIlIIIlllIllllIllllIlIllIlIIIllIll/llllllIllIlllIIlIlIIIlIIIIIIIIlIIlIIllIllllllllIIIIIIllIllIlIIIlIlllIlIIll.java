package llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lIlllIIIIllIIIlIIlllllIlIlIlllIlIIllllIIllIlIlIllllIlllIlIIIIIlIIIlIIl.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll;

import java.util.LinkedHashMap;
import net.minecraft.util.Vec3;

final class llllllIllIlllIIlIlIIIlIIIIIIIIlIIlIIllIllllllllIIIIIIllIllIlIIIlIlllIlIIll extends LinkedHashMap<Vec3, Vec3> {
   llllllIllIlllIIlIlIIIlIIIIIIIIlIIlIIllIllllllllIIIIIIllIllIlIIIlIlllIlIIll() {
      this.put(new Vec3(0.0D, 0.0D, 0.0D), new Vec3(0.0D, 0.0D, -4.0D));
      this.put(new Vec3(0.0D, 0.0D, -4.0D), new Vec3(-1.0D, 0.0D, -4.0D));
      this.put(new Vec3(-1.0D, 0.0D, -4.0D), new Vec3(-1.0D, 0.0D, -12.0D));
      this.put(new Vec3(-1.0D, 0.0D, -12.0D), new Vec3(15.0D, 0.0D, -12.0D));
      this.put(new Vec3(15.0D, 0.0D, -12.0D), new Vec3(15.0D, 0.0D, -11.0D));
      this.put(new Vec3(15.0D, 0.0D, -11.0D), new Vec3(14.0D, 0.0D, -11.0D));
      this.put(new Vec3(14.0D, 0.0D, -11.0D), new Vec3(14.0D, 0.0D, -13.0D));
      this.put(new Vec3(14.0D, 0.0D, -13.0D), new Vec3(5.0D, 0.0D, -13.0D));
      this.put(new Vec3(5.0D, 0.0D, -13.0D), new Vec3(5.0D, 0.0D, -6.0D));
      this.put(new Vec3(16.0D, 0.0D, -6.0D), new Vec3(5.0D, 0.0D, -6.0D));
   }
}
