package llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lIlllIIIIllIIIlIIlllllIlIlIlllIlIIllllIIllIlIlIllllIlllIlIIIIIlIIIlIIl.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll;

import java.util.HashMap;

final class lllIllIlllIlIllIlIllIllIlIllIllllIIIlIIIIlllIIIIlIlIIlllIIIIlIIIIlllIIIllllIlllIIIl extends HashMap<Integer, IIllIIllIIIIIlIIIlllIIlIIIIllIlIIllIIIIIllllIIlIIIlIllllIllIllIllIllIlIlllIllIIllll> {
   lllIllIlllIlIllIlIllIllIlIllIllllIIIlIIIIlllIIIIlIlIIlllIIIIlIIIIlllIIIllllIlllIIIl() {
      this.put(-1, new IIllIIllIIIIIlIIIlllIIlIIIIllIlIIllIIIIIllllIIlIIIlIllllIllIllIllIllIlIlllIllIIllll(true, new int[]{1, 1, -1, 1, 4, -1, -1, -2, -3, -1, 4, 2, 1}));
      this.put(1, new IIllIIllIIIIIlIIIlllIIlIIIIllIlIIllIIIIIllllIIlIIIlIllllIllIllIllIllIlIlllIllIIllll(true, new int[]{1, -1, -1, -1, 4, 1, -1, 2, -3, 1, 4, -2, 1}));
      this.put(2, new IIllIIllIIIIIlIIIlllIIlIIIIllIlIIllIIIIIllllIIlIIIlIllllIllIllIllIllIlIlllIllIIllll(false, new int[]{-2, 1, 1, 1, -1, 2, 1, -1, 1, -1, 1, -2, 1, 4, -2, 1}));
      this.put(3, new IIllIIllIIIIIlIIIlllIIlIIIIllIlIIllIIIIIllllIIlIIIlIllllIllIllIllIllIlIlllIllIIllll(false, new int[]{-2, 4, 1, -2, 2, -2, 1, 4, -2, 1}));
      this.put(4, new IIllIIllIIIIIlIIIlllIIlIIIIllIlIIllIIIIIllllIIlIIIlIllllIllIllIllIllIlIlllIllIIllll(false, new int[]{-2, 3, 1, -1, 1, -1, 1, -1, 1, 4, -1, -1, -1, 2}));
      this.put(6, new IIllIIllIIIIIlIIIlllIIlIIIIllIlIIllIIIIIllllIIlIIIlIllllIllIllIllIllIlIlllIllIIllll(false, new int[]{-1, 1, -1, 1, 1, 1, 1, -1, 1, -2, 1, 4, -2, 1}));
   }
}
