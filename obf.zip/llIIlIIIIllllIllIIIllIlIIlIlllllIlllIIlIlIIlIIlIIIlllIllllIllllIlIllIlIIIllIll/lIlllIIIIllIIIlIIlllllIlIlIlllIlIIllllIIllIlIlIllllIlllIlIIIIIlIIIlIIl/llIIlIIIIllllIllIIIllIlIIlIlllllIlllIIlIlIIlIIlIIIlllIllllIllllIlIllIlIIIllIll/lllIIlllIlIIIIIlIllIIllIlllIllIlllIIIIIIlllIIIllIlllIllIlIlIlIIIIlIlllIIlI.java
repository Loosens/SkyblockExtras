package llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.lIlllIIIIllIIIlIIlllllIlIlIlllIlIIllllIIllIlIlIllllIlllIlIIIIIlIIIlIIl.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll;

import java.util.HashMap;

final class lllIIlllIlIIIIIlIllIIllIlllIllIlllIIIIIIlllIIIllIlllIllIlIlIlIIIIlIlllIIlI extends HashMap<Integer, IIllIIllIIIIIlIIIlllIIlIIIIllIlIIllIIIIIllllIIlIIIlIllllIllIllIllIllIlIlllIllIIllll> {
   lllIIlllIlIIIIIlIllIIllIlllIllIlllIIIIIIlllIIIllIlllIllIlIlIlIIIIlIlllIIlI() {
      this.put(4, new IIllIIllIIIIIlIIIlllIIlIIIIllIlIIllIIIIIllllIIlIIIlIllllIllIllIllIllIlIlllIllIIllll(true, new int[]{3, -1, -3, -1, 1, -1, 1, 1, 1, -1, 3, 1, -2, 1, 1, 3, -2, -1, -3, 2, 1, -1, 1, 1, 4, -3, 1}));
      this.put(5, new IIllIIllIIIIIlIIIlllIIlIIIIllIlIIllIIIIIllllIIlIIIlIllllIllIllIllIllIlIlllIllIIllll(false, new int[]{1, 1, 1, -1, 1, 5, -1, 1, -1, -2, 1, -1, -2, -1, -1, -2, -2, 1, 1, 1, -1, 1, 2, 1, -2, 2, 1, -1, 2, 2}));
      this.put(6, new IIllIIllIIIIIlIIIlllIIlIIIIllIlIIllIIIIIllllIIlIIIlIllllIllIllIllIllIlIlllIllIIllll(false, new int[]{-3, 6, 1, -5, 3, -1, 2, 1, -1, 1, 1, 4, -1, -3, -3, 1, 2, 1, -1, 2}));
      this.put(8, new IIllIIllIIIIIlIIIlllIIlIIIIllIlIIllIIIIIllllIIlIIIlIllllIllIllIllIllIlIlllIllIIllll(true, new int[]{1, -1, -1, -2, 1, 1, 1, -1, 4, 1, -2, 1, 1, 1, -3, 1, 2, 1, -4, 1, 6, -3, 1}));
      this.put(10, new IIllIIllIIIIIlIIIlllIIlIIIIllIlIIllIIIIIllllIIlIIIlIllllIllIllIllIllIlIlllIllIIllll(false, new int[]{-1, 2, -1, -2, -1, 6, 1, -2, 1, 1, 2, -1, 1, -2, -1, -2, 2, 5, -1, 1, -2, 1}));
   }
}
