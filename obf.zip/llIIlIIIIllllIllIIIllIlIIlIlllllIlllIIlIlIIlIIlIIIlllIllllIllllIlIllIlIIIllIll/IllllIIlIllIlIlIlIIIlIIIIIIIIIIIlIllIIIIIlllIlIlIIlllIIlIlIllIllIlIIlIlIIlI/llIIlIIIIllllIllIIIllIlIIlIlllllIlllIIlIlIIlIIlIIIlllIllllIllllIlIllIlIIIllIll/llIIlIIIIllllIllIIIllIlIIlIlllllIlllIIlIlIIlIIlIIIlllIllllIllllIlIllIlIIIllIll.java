package llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll.IllllIIlIllIlIlIlIIIlIIIIIIIIIIIlIllIIIIIlllIlIlIIlllIIlIlIllIllIlIIlIlIIlI.llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll;

import io.netty.channel.ChannelHandlerContext;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.inventory.Slot;
import net.minecraft.network.Packet;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

public class llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll {
   private static String[] llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll;

   public static void IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(ChannelHandlerContext param0, Packet<?> param1, CallbackInfo param2) {
      // $FF: Couldn't be decompiled
   }

   public static void llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(ChannelHandlerContext param0, Packet<?> param1, CallbackInfo param2) {
      // $FF: Couldn't be decompiled
   }

   public static void llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(CallbackInfo param0, Slot param1, GuiContainer param2, int param3, int param4, int param5) {
      // $FF: Couldn't be decompiled
   }

   public static void llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(CallbackInfo param0, Slot param1, GuiContainer param2) {
      // $FF: Couldn't be decompiled
   }

   public static void llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(String[] var0) {
      llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll = var0;
   }

   public static String[] llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll() {
      return llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll;
   }

   private static Exception IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(Exception var0) {
      return var0;
   }

   static {
      try {
         if (llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll() != null) {
            llIIlIIIIllllIllIIIllIlIIlIlllllIlllIIlIlIIlIIlIIIlllIllllIllllIlIllIlIIIllIll(new String[1]);
         }

      } catch (RuntimeException var0) {
         throw IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(var0);
      }
   }

   private static RuntimeException IIIIlllIIlIIIIIlIlIIIlIIIlllIIIlllIIlllIllIllIIlIIIlIIIIIlIIIIIIIlllllllI(RuntimeException var0) {
      return var0;
   }
}
